#include "header.hpp"
#include "range_coding.hpp"
#include "state.hpp"
#include <cstdint>
#include <omp.h> 

RNG rng;

int64_t width=500;
const int64_t BLOCK_SIZE = 1<<22; // 4MB
const int64_t BLOCK_LIMIT_SIZE = 0.98 * BLOCK_SIZE;
int max_level = 1;
  int xxx = 1;
int search(int, int64_t,vector<int> , int, int );
struct tree_t {
  int             iinitial;
  vector<int>     initial;
  vector<uint8_t> data;
  range_encoder   out;

  tree_t() = default;
  tree_t(int iinitial_, vector<int> initial_)
    : iinitial(iinitial_),
      initial(initial_),
      data(BLOCK_SIZE),
      out(data.data()){ }
};

int max_overall = 0;

void process_tree
(int goal,
 tree_t const& tree,
 int val,
 vector<tree_t>& new_tree,
 vector<int64_t> & leaf_count ,
 int64_t& nleaf,
 int cutoff, float const& prob, vector<int> init_code, int level = 1)
{
  goal = max(goal,val);
  state ST; 
  ST.reset();
  
  ST.init_start(init_code);
 // ST.display2();
  int ncommit = 0;
  vector<tuple<int,int,int>> stack;
  vector<int> stack_count;
  if(new_tree.empty()) new_tree.eb(tree.iinitial, tree.initial);

  range_decoder in(tree.data.data());
  bool is_start_records = false;
  int rand_width = 0;
  int old_leaves = 0;
  while(1) {
    int is_down = in.get(2); in.update(is_down,1,2);
    if(is_down) {
    //  cout<<"a\n";
      int sz0 = ST.legal_moves2.length;//legalMoves();   
      int i = in.get(sz0); 
      in.update(i,1,sz0);
      if(i < sz0) {
        if(ST.is_valid_move(i)){
          ST.do_move(i,false,false);
          stack_count.eb(1);
          stack.eb(i,sz0,-1);
        }
      }
     //  cout<<"b\n";
    }else{
      if(ST.score == val) { // leaf
        int v = in.get(MAX_GOAL); in.update(v,1,MAX_GOAL);
        
        if(v > 0 && (v > cutoff || ((v == cutoff && rng.randomFloat() < prob)))){
          while(ncommit < (int)stack.size()) {
            int x,nx,d; tie(x,nx,d) = stack[ncommit];
            new_tree.back().out.put(1,1,2);
            new_tree.back().out.put(x,1,nx);
            if(d != -1) new_tree.back().out.put(d,1,8);
            ncommit += 1;
          }
          int isz0 = ST.legal_moves2.length;//legalMoves();
          ST.bottom = isz0 - 1;
          bool ok = false;

          // tutaj sa lisce ...
          int ile_ok = 0;
          FORD(i, isz0-1, 0 ) {
           // cout<<"process tree i: "<<i<<"\n";
            int low = ST.low;
            if(ST.is_valid_move(i,true)){
              ile_ok++;
              int iv =  0;
             if(ST.is_valid_move(i,true)){//} && (ile_ok<=7 )){
              if(level >= 0) {
              /* int ccc = ST.code(ST.legal_moves2.mv[i]);
                if(SEQ_OLD_SIZE[level][old_leaves]>0 && SEQ_OLD[level][old_leaves][0] == ccc) {
                  FOR(ii,SEQ_OLD_SIZE[level][old_leaves]-1) {
                    SEQ[level][nleaf][ii] = SEQ_OLD[level][old_leaves][ii+1];
                  }
                  SEQ_SIZE[level][nleaf] = SEQ_OLD_SIZE[level][old_leaves] - 1;
                  SEQ_SCORE[level][nleaf] = SEQ_OLD_SCORE[level][old_leaves];
                } else {
                  SEQ_SIZE[level][nleaf] = 0;
                  SEQ_SCORE[level][nleaf] = 0;
                }*/
              }



              ST.do_move(i,false,true);
              if(ST.bad_count == 0 && level == max_level) {
                is_start_records = true;
              }
              if(level >=1){
                vector<int> init_code_current;
                init_code_current.clear();
                FOR(i,ST.length){
                  init_code_current.push_back(ST.seq_code[i]);
                }
           //     FOR(i,CODES)rank_max_score[1][i]=rank_max_score[0][i];
            //   FOR(i,CODES)rank_max_score[0][i]= rand()%8;//max_code[i];

                   iv = search(goal,width,init_code_current, level-1,cutoff);
 //FOR(i,CODES)rank_max_score[0][i]=rank_max_score[1][i];
               /* SEQ_OLD_SIZE[level-1][0] = 0;
                SEQ_OLD_SCORE[level-1][0] = 0;
                SEQ_SIZE[level-1][0] = 0;
                SEQ_SCORE[level-1][0] = 0;


             
                


                if(iv < SEQ_SCORE[level][nleaf]){
               //   iv = SEQ_SCORE[level][nleaf];
                }
*/
              } else {
              
                iv =  ST.move_score(low,i-1,nleaf);

               // if(iv < SEQ_SCORE[level][nleaf]){
               //  iv = SEQ_SCORE[level][nleaf];
               // }


              }
              runtime_assert(iv < MAX_GOAL);
               ST.undo_move();
              }  else {
                iv = 0;
              }
              if(iv != 0) { 

                nleaf += 1;
                leaf_count[iv] += 1;
                new_tree.back().out.put(1,1,2); // down
                new_tree.back().out.put(i,1,isz0); // which
                new_tree.back().out.put(0,1,2); // up
                new_tree.back().out.put(iv,1,MAX_GOAL); // leaf
              }
            }
          }
        } 
        if(level == 0)
          old_leaves++;
      }
      if(stack_count.empty()) break;
      FOR(i,stack_count.back()) ST.undo_move();
      if(ncommit == (int)stack.size()) { new_tree.back().out.put(0,1,2); ncommit -= 1; }
      stack_count.pop_back(); stack.pop_back();
      if(new_tree.back().out.size > BLOCK_LIMIT_SIZE) {
        FORD(i,ncommit-1,0) FOR(j,stack_count[i]) new_tree.back().out.put(0,1,2);
        new_tree.back().out.put(0,1,2);
        new_tree.back().out.finish();
        new_tree.eb(tree.iinitial, tree.initial);
        new_tree.back().out = range_encoder(new_tree.back().data.data());
        FOR(i,ncommit) {
          int x,nx,d; tie(x,nx,d) = stack[i];
          new_tree.back().out.put(1,1,2);
          new_tree.back().out.put(x,1,nx);
          if(d != -1) new_tree.back().out.put(d,1,8);
        }
      }
    }
  }
  //cout<<"process tree koniec WHILE\n";
  const std::string red("\033[1;31m");
    const std::string green("\033[1;32m");
    const std::string reset("\033[0m");
  if(level == max_level) {
    if(is_start_records) {
      cout<<green<<"SUCCESS\n"<<reset;;
    } else {
      cout<<red<<"FAILED\n"<<reset;
    }
  }

  if(level >= 0) {
    FOR(i,nleaf){
      FOR(j,SEQ_SIZE[level][i]){
        SEQ_OLD[level][i][j]=SEQ_OLD[level][i][j];
      }
      SEQ_OLD_SIZE[level][i] = SEQ_SIZE[level][i];
      SEQ_OLD_SCORE[level][i] = SEQ_SCORE[level][i];
    }
  }

 // cout<<old_leaves<<" -> "<<nleaf<<"\n";
}

vector<tree_t> initial_tree() {
  vector<tree_t> T;
  //auto IS = initial_states();
//  FOR(i,IS.size()) {
  vector<int> k(1);
    T.eb(0,k);
    range_encoder out(T.back().data.data());
    out.put(0,1,2);
    out.put(1,1,MAX_GOAL);
    out.finish();
  //}
  return T;
}

int search(int goal, int64_t beam_width,vector<int>  init_code, int level = 1, int cutoff_deep = 0 ) {
  int64_t beam_width_init = beam_width;
  vector<tree_t> T = initial_tree();
  int ninitial = T.size();
  int  cutoff = 0;
  float prob = 1.0;
  int max_high = 0;
  
  
  state ST;
  ST.reset();
  //if(level==0){
    ST.init_start(init_code);
  //}


  FORU(val,ST.get_score(),goal+20) {
   // val=1;
    timer TIMER;

   // std::cout<<"val: "<<val<<"\n";

    int iblock = 0;

    vector<tree_t> R;
    vector<int64_t> leaf_count(MAX_GOAL+1,0);
    int64_t nleaf = 0;


    omp_set_num_threads(1);
    #pragma omp parallel num_threads(1)
    {

      vector<vector<tree_t>> local_R(ninitial);
      vector<int64_t> local_leaf_count(MAX_GOAL+1,0);
      int64_t local_nleaf = 0;
      while(1) {
        tree_t T0;
        #pragma omp critical
        {
        if(!T.empty()) {
            T0 = move(T.back());
            T.pop_back();
          }else{
            T0.data.clear();
          }
        }
        
        if(T0.data.empty()) break;
        process_tree( goal,
                     T0, val,
                     local_R[T0.iinitial], local_leaf_count, local_nleaf,
                     cutoff, prob,init_code,level);
       // cout<<"SEATCH - po process tree\n";
        iblock += 1;
        
      }
       #pragma omp critical
      {

      while(!local_R.empty()) {
          if(!local_R.back().empty()) local_R.back().back().out.finish();
          while(!local_R.back().empty()){
            R.eb(move(local_R.back().back())); local_R.back().pop_back();
          }
          local_R.pop_back();
        }
        FOR(i,MAX_GOAL) leaf_count[i] += local_leaf_count[i];
        nleaf += local_nleaf;
      }
      
    
    }
    T = move(R);

    int64_t cnts = 0;
    FORD(i,MAX_GOAL-1,1) 
      cnts += leaf_count[i];
    double div = 1;
    if(val%3){
      beam_width = beam_width_init*div;
    } else {
      beam_width = beam_width_init*div;
    }
    
    float inner_beam_width;
    { float lo = 1, hi = beam_width;
      FOR(k,200) {
        float mi = (lo+hi)/2;
        int64_t tot_mi = 0; 
        tot_mi += min<int64_t>(cnts, mi);
        if(tot_mi > beam_width) hi = mi;
        else lo = mi;
      }
      inner_beam_width = lo;
    }

   // cout << "\r\e[K" << flush;


    int64_t cnt = 0;
    cutoff=0; prob=1.0;
    int high=0;
    int64_t local_beam_width = inner_beam_width;;
    FORD(i,MAX_GOAL-1,1) {
      if(leaf_count[i]) high = max<int>(high, i);
      if(leaf_count[i])
      if(cnt+leaf_count[i] > local_beam_width) {
        cutoff = i;
        prob = (float)(local_beam_width-cnt)/(float)leaf_count[i];
        break;
      }
      cnt += leaf_count[i];
    }
    /*FOR(i,_score){
      cout<<_moves[i]<<": "<<max_code[_moves[i]]<<"\n";
    }*/
   /* FOR(i,6400){
      if(max_code[i]>0)
      cout<<i<<": "<<max_code[i]<<"\n";
    }
    cout<<"\n";*/
    if(level==10) {
      if(cutoff_deep*0.85 > max_high && val >= init_code.size()+3) {
        return max_high;
      }
    }
    if(level>=max_level){//} && level !=0){
   //   max_code_valid = 70;
   // if(high > 0) { 
      cout<<"LEVEL "<<level<<"\n";
      cout  << ", cutoff: " << cutoff
            << ", high: " << high
            << ", width: " << local_beam_width
            << endl;
 //   }
    
    
    cout << ", val: " << setw(3) << val
         << ", goal: " << setw(3) << goal
         << ", elapsed: " << fixed << TIMER.elapsed()
         << ", width: " << inner_beam_width
         << ", size: " << T.size()
         << ", leaves: " << nleaf
      // << ", bests: " << vector<float>(T.best, T.best+maxn+1)
         << endl;
    }
    if(level>=0){
      int min_rec = 1000;
      int suma_max_code = 0;
      FOR(i,CODES){
        if(level == max_level && level >=2){
        state_code[i]=0;
        action_code[i]=0;
        }
        suma_max_code += max_code[i];
        if(records[i]){
          if(level == max_level && level >=1)
          cout<<(max_code[i]<=9?" ":"")<<max_code[i]<<" ";
          if(max_code[i]>0 && max_code[i] < min_rec){
            min_rec = max_code[i];
          }
        }
      }
      int ile = 0;
      int ile2 = 0;
       if(level == max_level && level >=1) {
      FOR(i,CODES){
        if(!records[i]){
          if(max_code[i]>0 && max_code[i] < min_rec){
            ile++;
          } else if(max_code[i]>0 && max_code[i] >= min_rec){
            ile2++;
          }
        }
      }
        
        /*state ST2;
        int ii = 1;
        cout<<"\n\n";
        ST2.reset(5);
        while(ST2.low < ST2.legalMoves()) {
          int c = ST2.code(ST2.legal_moves.mv[ST2.low]);
          if(ST2.is_valid_move(ST2.low) && records[c]){
            cout<<(ii<10?" ":"")<<(ii<100?" ":"")<<ii<<": "<<(max_code[c]<10?" ":"")<<(max_code[c]<100?" ":"")<<max_code[c]<<" - "<<c<<"\t";
            ii++;
            ST2.do_move(ST2.low,false,false);
             ST2.nextMove();
          } else{
            ST2.low++;
            ST2.nextMove();
          }
        }*/
         }
       if(level == max_level && level >=1){
      cout<<"\n\n min_rec: "<<min_rec<<" ile: "<<ile<<" ile2: "<<ile2<<"\tsuma ile:"<<ile+ile2<<"\tsuma_max_code: "<<suma_max_code<<"\n";
       
      cout<<"\n\n";
      }
      min_code_valid = min_rec;
    }
    
    if(max_high < high){max_high = high;}
    if(max_overall <high){
      max_overall = high; cout<<"max_overall: "<<max_overall<<"\n";
      
      xxx=1;
      max_code_valid = max_overall;
    max_code_valid=max_overall;
    }
    if(nleaf == 0) {
      
     break;
    }
  }
  return max_high;
}


void test_record() {
  int layer_size = 0;
  read(178,0,0);
  state ST;
  ST.reset(0);
  ST.low  = 0;
  int iii = 0;
  while(ST.low < ST.legalMoves()){
  
    if(ST.is_valid_move(ST.low)) {
        cout<<ST.low<<"\t";
      iii++;
      cout<<"V";
      if( records[ST.code(ST.legal_moves.mv[ST.low])]){
      ST.do_move(ST.low,false,false);
      cout<<"R";
      } else {
        ST.low++;
      }
        cout<<"\n";
    }else {
      ST.low++;
    }
    
  }
  cout<<"iii: "<<iii<<"\n";
  cout<<"\n\n";
  ST.reset(0);
  ST.low  = 0;
  int k = ST.legalMoves()-1;
  cout<<"ST.legalMoves(): "<<ST.legalMoves()<<"\n";
  bool kk[2000];
  FOR(i,2000){
    kk[i]=false;
  }
  iii = 0;
  while(k>=0){
    if(!kk[k] && ST.is_valid_move(k)) {
      iii++;
      kk[k]=true;
      cout<<k<<" ";
      if(records[ST.code(ST.legal_moves.mv[k])]){
        cout<<"d";
        ST.do_move(k,false,false);
        k = ST.legalMoves()-1;
      } else {
        k--;
      }
      cout<<"\n";
    } else {
      kk[k]=true;
      k--;
    }

  }
  cout<<"iii: "<<iii<<"\n";

   std::cout<<"\nscore :"<<ST.get_score()<<"\n";
  ST.clear_rep();
 
  int hh;std::cin>>hh;
}


void test_record2() {
  read(178,0,0);
  cout<<"test_record2\n";
  state ST;
  ST.reset(5);
  int iii = 0;
  int g = 0;
  while(ST.bottom>=0){
   // cout<<ST.bottom<<" ST.legal_moves2.length: "<<ST.legal_moves2.length<<"\n";
    if(ST.is_valid_move(ST.bottom)) {
        cout<<ST.bottom<<" ";
      iii++;
      cout<<"V";
      if( records[ST.code(ST.legal_moves2.mv[ST.bottom])]){
        ST.do_move(ST.bottom,false,true);
        g++;
        if(g%5==-2){
          ST.undo_move();
        }
       cout<<"R"<<" sym = "<<ST.move_score(0,0,0);
      } else {
        ST.bottom--;
      }
      cout<<": "<<ST.score<<"\n";
    }else {
      ST.bottom--;
    }
  }
  cout<<"iii: "<<iii<<"\n";
  cout<<"\n\n";

  std::cout<<"\nscore :"<<ST.get_score()<<"\n";
  ST.clear_rep();
 
  int hh;std::cin>>hh;
}

//layer []
bool t[CODES];
void similar() {
  read(178);
  FOR(s,2){
    FOR(o,4){
  read(170,1,0,t);
  int ile = 0;
  FOR(i,CODES){
    if(records[i] && records[i]==t[i]){
      cout<<i<<", ";
      ile++;
    }
  }
  cout<<"\nile: "<<ile<<"\n";
    }}
  //rotacje + symetria
  //read(172);
  //ile_wspolnych

  //--ile_wspolnych
}

int main(int argc, char** argv){
 // read_pantasol();
  //read_policy();
 //  read(178,0,0);
 // similar();

 // read_pantasol();
  //int yyy;cin>>yyy;

  //cout << magenta<<"\u25A0";
  //cout<<"x";
 
  
  int goal=178; 
  
  timer TIMER;
  vector<int> init_code;
/*init_code.push_back(2474);
init_code.push_back(2468);
init_code.push_back(2481);
init_code.push_back(3444);
     */
 // cout<<"search"<<search(goal,1000, init_code,0,0);
  //test_record2();
  read(178,0,0);
  FOR(i,CODES)rank_max_score[0][i]=0;//rand()%10000;// max_code[i];

  current_best = 0;
  FOR(i,CODES)
    max_code[i]=0;
  max_level = 0;
  int k = 2;
  width=300;
  while(k--) {
    cout<<"search"<<search(goal,width, init_code,(int)max_level,0);
  }

  max_code_valid2 = max_overall-xxx;
  max_level =0;
    FOR(i,CODES)rank_max_score[0][i]= max_code[i];
  width=10000;
  while(1){
    cout<<max_code_valid2<<"search"<<search(goal,width, init_code,(int)max_level,0)<<"\n";
    max_code_valid2 = max_overall-xxx;
    xxx+=2;
    FOR(i,CODES)rank_max_score[0][i]= 1;//max_code[i];
    width+=50;
  }
  /*max_code_valid = 0;
    width=500;
    cout<<"search"<<search(goal,width, init_code,(int)1);
    // test_record();
  
 FORU(x,1,178){
    init_move = x;
    FOR(i,6400)max_code[i]=0;
  //  max_high = 0;
    cout<<"x: "<<init_move<<" = ";disp
    vector<int> init_code;    
    search(goal,width, init_code);
   // cout<<max_high;
    cout<<"\n";
  }*/
  
 // max_code_valid = 61;
 /*
  int aa;cin>>aa;
  int x = 70;
  while(1) {
    search(goal,width);
    x++;
    max_code_valid=x;
    width=100'000'000;
  }*/
  cout << "total elapsed: " << TIMER.elapsed() << endl;

  return 0;
}
// c++ -std=c++17 -O3 beam.cpp -fopenmp -o dfs_p
//c++ -std=c++17 -O3 beam.cpp -fopenmp -o dfs_p