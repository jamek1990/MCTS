
#include "state.hpp"
#include "header.hpp"


int dfs_node[200];
int dfs_value[200];
int dfs_count_wynik[200][200];
int dfs_count[200];

int best_score = 0;

void dfs(){

    state ST;
    double x = 1; 
    
    while(1){
        FOR(i,200)dfs_value[i]=30;
        x+=1;
    ST.reset();
    int level = 1;
    dfs_node[level] = ST.low;

    
    while(true){
        bool down = false;
        //cout<<"a";
        // test 
        int value = 0;
        int w = 0;
        bool ok = false;
         value = ST.move_score();
          if(value > best_score){
                best_score = value;
                std::cout<<best_score<<"\n";
            }

        if((level%16)>=4){
        
        //if(level > 1) {
            //cout<<ST.get_score()<<" "<<level<<"\n";
           
            dfs_count_wynik[level][value]++;
            dfs_count[level]++;
            int ile =0;
            w = 0;
            FORD(i,best_score,0){
                ile+=dfs_count_wynik[level][i];
                if(ile >=  dfs_count[level]*0.49) {
                    w = i;
                    break;
                }
            }
            //cout<<"lewel: "<<level<<" - "<<w<<" "<<value<<"\n";
           //int oo;cin>>oo;
          //  std::cout<<value<<"\n";
            if(value > best_score){
                best_score = value;
                std::cout<<best_score<<"\n";
            }

        }else{
            ok = true;
        }
        if(value-level<max(25,80-(int)x-(int)level/2)){
                value = -1;
                ok = false;
            }
            //std::cout<<value<<"\n";
        //}
        if(value +x >= w || ok) {
            //cout<<"a";
            if(value > dfs_value[level]) {
                dfs_value[level] = value;
            }
            while(dfs_node[level]<ST.legalMoves()){
                Move m = ST.legal_moves.mv[dfs_node[level]];
                if(ST.CanMove(m.pos,m.dir)){
                    down = true;
                    break;
                }
                dfs_node[level]++;
            }
        }
        if(down){
            ST.do_move(dfs_node[level]);
            dfs_node[level]++;
            level++;
            dfs_node[level] = ST.low;
        } else {
            if(level > best_score){
                best_score = level;
                std::cout<<best_score<<"\n";
            }
            ST.undo_move();
            level--;
            if(level <1)break;
        }
    }
   // FOR(i,best_score)cout<<"i: "<<i<<"\t - "<<dfs_count_wynik[i][i]/(dfs_count[i]+1)<<"\n";
  std::cout<<"N\n";
    }
}



int main(int argc, char** argv){
  dfs();
  return 0;
}
