#include "header.hpp"

const int dx[8] = {1,1,1,0,-1,-1,-1,0};
const int dy[8] = {-1,0,1,1,1,0,-1,-1};

const int MAXN     = 31;

vector<vector<int>> parse(istream& is) {
  vector<vector<int>> V;

  while(!is.eof()) {
    while(is.peek() == ' ') is.get();
    if(is.peek() == '(') {
      is.get();
      V.eb();
      continue;
    }
    if(is.peek() == ')' || is.peek() == ',') {
      is.get();  continue;
    }
    if('0' <= is.peek() && is.peek() <= '9') {
      int x; is>>x;
      while(is.peek() == ' ') is.get();
      if(is.peek() == ':') { // skip x
        FOR(i,x) V.back().eb(0);
        is.get();  continue;
      }else if(is.peek() == ',' || is.peek() == ')' || is.peek() == '/') { // use x
        V.back().eb(x);
        is.get();  continue;
      }
    }
    is.get();
  }

  return V;
}

int best[MAXN+1];
map<int,map<int,int>> sols[MAXN+1];

void work(int N, int tgtN, vector<vector<int>> V) {
  int n = V.size();
  int m = 0;
  FOR(i,n) smax(m, (int)V[i].size());
  FOR(i,n) V[i].resize(m,0);

  int max_cell = 0;
  FOR(i,n) FOR(j,m) smax(max_cell,V[i][j]);
  vector<tuple<int,int>> at(max_cell+1);
  FOR(i,n) FOR(j,m) if(V[i][j] > 1) at[V[i][j]] = mt(i,j);

  auto is_empty = [&](int i, int j){
    return i<0||i>=n||j<0||j>=m||V[i][j] == 0;
  };
  auto is_clear = [&](int i, int j){
    if(!is_empty(i,j)) return false;
    FOR(d,8) if(!is_empty(i+dx[d],j+dy[d])) return false;
    return true;
  };
  auto all_clear = [&](int i1, int j1, int i2, int j2){
    if(i1 > i2) swap(i1,i2);
    if(j1 > j2) swap(j1,j2);
    FORU(i,i1,i2) FORU(j,j1,j2) if(!is_clear(i,j)) return false;
    return true;
  };

  while(max_cell >= 2 && max_cell + 6*(tgtN-N)-1 > best[tgtN]) {
    int i,j; tie(i,j) = at[max_cell];
    V[i][j] = 0;
    FOR(d,8) if((d&1) == 0) {
      if(all_clear(i+dx[d],j+dy[d], i+3*dx[d], j+3*(tgtN-N)*dy[d])) {
        best[tgtN] = max_cell + 6*(tgtN-N)-1;
        map<int,map<int,int>> sol;
        FOR(i,n) FOR(j,m) if(V[i][j]) sol[i][j] = V[i][j];
        sol[i][j] = max_cell;
        FOR(x,tgtN-N) sol[i+2*dx[d]][j+(2+3*x)*dy[d]] = 1;
        FOR(x,3*(tgtN-N)-1) sol[i+1*dx[d]][j+(1+x)*dy[d]] = ++max_cell;
        sol[i+2*dx[d]][j+(3*(tgtN-N))*dy[d]] = ++max_cell;
        FORD(x,3*(tgtN-N)-2,0) sol[i+3*dx[d]][j+(1+x)*dy[d]] = ++max_cell;
        sols[tgtN] = sol;
        return;
      }
      if(all_clear(i+dx[d],j+dy[d], i+3*(tgtN-N)*dx[d], j+3*dy[d])) {
        best[tgtN] = max_cell + 6*(tgtN-N)-1;
        map<int,map<int,int>> sol;
        FOR(i,n) FOR(j,m) if(V[i][j]) sol[i][j] = V[i][j];
        sol[i][j] = max_cell;
        FOR(x,tgtN-N) sol[i+(2+3*x)*dx[d]][j+2*dy[d]] = 1;
        FOR(x,3*(tgtN-N)-1) sol[i+(1+x)*dx[d]][j+1*dy[d]] = ++max_cell;
        sol[i+(3*(tgtN-N))*dx[d]][j+2*dy[d]] = ++max_cell;
        FORD(x,3*(tgtN-N)-2,0) sol[i+(1+x)*dx[d]][j+3*dy[d]] = ++max_cell;
        sols[tgtN] = sol;
        return;
      }
    }
    max_cell -= 1;
  }
}

int main(){
  FORU(n,7,MAXN) {
    for(auto it = filesystem::directory_iterator(filesystem::path("solutions/" + int_to_string(n,2)));
        it != filesystem::directory_iterator(); ++it) {
      ifstream is(it->path());
      auto V = parse(is);
      is.close();
      FORU(m,n+1,MAXN) work(n, m, V);
    }
  }

  FORU(n,7,MAXN) {
    auto sol = sols[n];
    cout << "sol " << n << " " << best[n] << endl;

    filesystem::create_directories("solutions/" + int_to_string(n,2));
    ofstream os("solutions/" + int_to_string(n,2) + "/" + int_to_string(best[n],3));

    int minx = 9999, maxx = -9999;
    int miny = 9999;
    for(auto const& p : sol) {
      minx = min(minx, p.first);
      maxx = max(maxx, p.first);
      for(auto const& q : p.second) {
        miny = min(miny, q.first);
      }
    }

    bool firstline = true;
    FORU(i,minx,maxx) {
      if(!firstline) os << ", (";
      bool firstitem = true;
      int last = -2;
      for(auto [j,v] : sol[i]) {
        if(firstitem) {
          if(firstline) {
            os << '(';
            firstline = false;
          }
          os << j-miny << ":";
          firstitem = false;
        }else{
          if(j != last+1) {
            os << "/";
            os << (j-last-1) << ":";
          }else{
            os << ",";
          }
        }
        os << (int)v;
        last = j;
      }
      if(!firstline) os << ')';
    }
    os << endl;
  }

  return 0;
}
