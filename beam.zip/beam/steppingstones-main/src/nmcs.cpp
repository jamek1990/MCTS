#include "header.hpp"
#include "range_coding.hpp"
#include "state.hpp"
#include <cstdint>
#include <omp.h>

const int MAX_LEVEL = 10;
const int MAX_SEQ_SIZE = 200;
struct level_struct{
    int position = 0;
    int best_seq[200];
    int best_seq_length = 0;
    int best_score = 0;
    int length = 0;
};
level_struct L[10];

map<long long, level_struct>zbior;

void nmcs(int level) {
    state ST;
    ST.reset();
    L[level].position = ST.low;
    L[level].best_score = 0;
    L[level].best_seq_length = 0;
    L[level].length = 0;
    L[0].position = 0; // ?? tu bardzo duza - upraszcza implementacje
    int best_score = 0;
    int iter = 0;
    while(1){
        if(level>=1) {
           // cout<<"level: "<<level<<" length: "<<L[level].length<<" position - "<<L[level].position<<" score "<<L[level].best_score<<" length: "<<L[level].best_seq_length<<"\n";
          //  int gg; cin>>gg;
        }
        if(level == 0) {
            iter++;
            if(iter%10000000==0){
                cout<<iter<<"\n";
            }
            // tutaj symulujemy...
            int st = ST.fast_simple0();
           // cout<<st<<"\n";
            if(best_score <st){
                best_score = st;
                 cout<<best_score<<"\n";
                 int yy;cin>>yy;
            }
            if(L[level+1].best_score < ST.score){
                L[level+1].best_score = ST.score;
                FOR(i,ST.best_seq_length){
                    L[level+1].best_seq[i] = ST.best_seq[i];
                }
                L[level+1].best_seq_length = ST.best_seq_length;
            }
            //cout<<ST.length<<" "<<L[level+1].length<<"\n";
            while(ST.length > L[level+1].length) {
                ST.undo_move();
            }
            level++;
        }
        else if(L[level].position < ST.legalMoves()) {
            ST.nextMove();
            if(ST.low>L[level].position)
                L[level].position = ST.low;
            if(L[level].position >=  ST.legalMoves())continue;
            ST.do_move(L[level].position);
            ST.nextMove();
            L[level].position = ST.low;
            level--;
            L[level].position = L[level+1].position; // od pozycji wyzeszego levelu, aby uniknac permutacji || 0 jesli nie ma problemu z permutacjami
            L[level].best_score = 0;
            L[level].best_seq_length= 0;
            L[level].length= ST.length;
            if(level>=2){
                auto it = zbior.find(((ST.hash<<2)+level));
                if (it != zbior.end()){
                
                // cout<<"opt\n";
                    level_struct ls = it->second;
                    if(ls.length == L[level].length){
                       // cout<<"opt";
                        L[level] = ls;
                        L[level].length= 1000000;//L[level+1].length+1;
                        L[level].position = 100000000;
                    }
                }
            }
        } else {
            //if(level==4)
                //cout<<"LEVEL 4: score - "<<L[level].best_score<<" length - "<<L[level].length<<"\n";
            // doszlismy do konca wiec -- idziemy w dol lub... wracamy...
            if(L[level].length < L[level].best_seq_length) {
                if(level>=2) {
                    level_struct ls;
                    ls.best_score = L[level].best_score;
                    ls.best_seq_length =  L[level].best_seq_length;
                    FOR(i,ls.best_seq_length )
                        ls.best_seq[i]=L[level].best_seq[i];
                    ls.length = L[level].length;
                    zbior[((ST.hash<<2)+level)]=  ls;
                }
                ST.do_move(L[level].best_seq[L[level].length++],false);
                ST.nextMove();
                ST.low = 0;
                L[level].position = 0;//L[level+1].position;
            } else {
                //if(level==4)
                //    cout<<"LEVEL 4: score - "<<L[level].best_score<<" length - "<<L[level].length<<"\n";

                if(L[level+1].best_score < L[level].best_score){
                    L[level+1].best_score = L[level].best_score;
                    FOR(i,L[level].best_seq_length){
                        L[level+1].best_seq[i] = L[level].best_seq[i];
                    }
                    L[level+1].best_seq_length = L[level].best_seq_length;
                }
                while(ST.length > L[level+1].length) {
                    ST.undo_move();
                }
                level++;
            }

        }
    }

}

int main(int argc, char** argv){
    gen_hash_array();
    nmcs(7);
    return 0;
}