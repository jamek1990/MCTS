val: 2
, cutoff: 0, high: 51, width: 200000
, val:   2, goal: 178, elapsed: 0.019660, width: 200000.000000, size: 1, leaves: 24
val: 3
, cutoff: 0, high: 56, width: 200000
, val:   3, goal: 178, elapsed: 0.013809, width: 200000.000000, size: 1, leaves: 274
val: 4
, cutoff: 0, high: 58, width: 200000
, val:   4, goal: 178, elapsed: 0.017084, width: 200000.000000, size: 1, leaves: 1985
val: 5
, cutoff: 0, high: 58, width: 200000
, val:   5, goal: 178, elapsed: 0.060603, width: 200000.000000, size: 1, leaves: 10268
val: 6
, cutoff: 0, high: 59, width: 200000
, val:   6, goal: 178, elapsed: 0.187333, width: 200000.000000, size: 1, leaves: 40460
val: 7
, cutoff: 0, high: 59, width: 200000
, val:   7, goal: 178, elapsed: 0.271900, width: 200000.000000, size: 1, leaves: 126593
val: 8
, cutoff: 10, high: 61, width: 200000
, val:   8, goal: 178, elapsed: 0.697359, width: 200000.000000, size: 1, leaves: 324236
val: 9
, cutoff: 14, high: 61, width: 200000
, val:   9, goal: 178, elapsed: 1.512961, width: 200000.000000, size: 1, leaves: 656592
val: 10
, cutoff: 36, high: 61, width: 200000
, val:  10, goal: 178, elapsed: 3.001396, width: 200000.000000, size: 1, leaves: 785048
val: 11
, cutoff: 46, high: 62, width: 200000
, val:  11, goal: 178, elapsed: 4.590205, width: 200000.000000, size: 1, leaves: 677712
val: 12
, cutoff: 49, high: 62, width: 200000
, val:  12, goal: 178, elapsed: 4.981673, width: 200000.000000, size: 1, leaves: 663792
val: 13
, cutoff: 51, high: 62, width: 200000
, val:  13, goal: 178, elapsed: 5.140119, width: 200000.000000, size: 1, leaves: 639103
val: 14
, cutoff: 52, high: 62, width: 200000
, val:  14, goal: 178, elapsed: 5.319592, width: 200000.000000, size: 1, leaves: 630459
val: 15
, cutoff: 53, high: 62, width: 200000
, val:  15, goal: 178, elapsed: 5.422315, width: 200000.000000, size: 1, leaves: 649920
val: 16
, cutoff: 54, high: 64, width: 200000
, val:  16, goal: 178, elapsed: 5.984447, width: 200000.000000, size: 1, leaves: 699593
val: 17
, cutoff: 54, high: 63, width: 200000
, val:  17, goal: 178, elapsed: 6.601236, width: 200000.000000, size: 1, leaves: 772377
val: 18
, cutoff: 55, high: 63, width: 200000
, val:  18, goal: 178, elapsed: 7.060891, width: 200000.000000, size: 1, leaves: 859344
val: 19
, cutoff: 56, high: 64, width: 200000
, val:  19, goal: 178, elapsed: 7.823525, width: 200000.000000, size: 1, leaves: 959772
val: 20
, cutoff: 56, high: 64, width: 200000
, val:  20, goal: 178, elapsed: 8.632244, width: 200000.000000, size: 1, leaves: 1061540
val: 21
, cutoff: 57, high: 64, width: 200000
, val:  21, goal: 178, elapsed: 9.346746, width: 200000.000000, size: 1, leaves: 1149079
val: 22
, cutoff: 57, high: 67, width: 200000
, val:  22, goal: 178, elapsed: 10.046522, width: 200000.000000, size: 1, leaves: 1228445
val: 23
, cutoff: 58, high: 67, width: 200000
, val:  23, goal: 178, elapsed: 10.148140, width: 200000.000000, size: 1, leaves: 1288679
val: 24
, cutoff: 58, high: 67, width: 200000
, val:  24, goal: 178, elapsed: 10.635823, width: 200000.000000, size: 1, leaves: 1362449
val: 25
, cutoff: 59, high: 65, width: 200000
, val:  25, goal: 178, elapsed: 10.872164, width: 200000.000000, size: 1, leaves: 1441743
val: 26
, cutoff: 59, high: 67, width: 200000
, val:  26, goal: 178, elapsed: 11.115122, width: 200000.000000, size: 1, leaves: 1536913
val: 27
, cutoff: 59, high: 67, width: 200000
, val:  27, goal: 178, elapsed: 11.727273, width: 200000.000000, size: 1, leaves: 1627721
val: 28
, cutoff: 60, high: 68, width: 200000
, val:  28, goal: 178, elapsed: 11.788918, width: 200000.000000, size: 2, leaves: 1719028
val: 29
, cutoff: 60, high: 68, width: 200000
, val:  29, goal: 178, elapsed: 11.946861, width: 200000.000000, size: 3, leaves: 1787925
val: 30
, cutoff: 61, high: 68, width: 200000
, val:  30, goal: 178, elapsed: 11.496169, width: 200000.000000, size: 4, leaves: 1851325
val: 31
, cutoff: 61, high: 68, width: 200000
, val:  31, goal: 178, elapsed: 10.845366, width: 200000.000000, size: 5, leaves: 1916631
val: 32
, cutoff: 61, high: 68, width: 200000
, val:  32, goal: 178, elapsed: 10.579013, width: 200000.000000, size: 6, leaves: 1952607
val: 33
, cutoff: 62, high: 68, width: 200000
, val:  33, goal: 178, elapsed: 9.893217, width: 200000.000000, size: 6, leaves: 1951742
val: 34
, cutoff: 62, high: 68, width: 200000
, val:  34, goal: 178, elapsed: 9.663918, width: 200000.000000, size: 7, leaves: 1965357
val: 35
, cutoff: 62, high: 68, width: 200000
, val:  35, goal: 178, elapsed: 9.503169, width: 200000.000000, size: 8, leaves: 1980027
val: 36
, cutoff: 63, high: 69, width: 200000
, val:  36, goal: 178, elapsed: 8.829194, width: 200000.000000, size: 8, leaves: 1955113
val: 37
, cutoff: 63, high: 69, width: 200000
, val:  37, goal: 178, elapsed: 8.498130, width: 200000.000000, size: 9, leaves: 1905781
val: 38
, cutoff: 64, high: 69, width: 200000
, val:  38, goal: 178, elapsed: 8.028976, width: 200000.000000, size: 8, leaves: 1835269
val: 39
, cutoff: 64, high: 69, width: 200000
, val:  39, goal: 178, elapsed: 7.411696, width: 200000.000000, size: 7, leaves: 1781038
val: 40
, cutoff: 64, high: 69, width: 200000
, val:  40, goal: 178, elapsed: 7.086124, width: 200000.000000, size: 7, leaves: 1728701
val: 41
, cutoff: 65, high: 69, width: 200000
, val:  41, goal: 178, elapsed: 6.829360, width: 200000.000000, size: 7, leaves: 1637973
val: 42
, cutoff: 65, high: 69, width: 200000
, val:  42, goal: 178, elapsed: 6.349232, width: 200000.000000, size: 5, leaves: 1571235
val: 43
, cutoff: 65, high: 69, width: 200000
, val:  43, goal: 178, elapsed: 5.904803, width: 200000.000000, size: 5, leaves: 1524737
val: 44
, cutoff: 65, high: 70, width: 200000
, val:  44, goal: 178, elapsed: 5.460936, width: 200000.000000, size: 5, leaves: 1467811
val: 45
, cutoff: 66, high: 70, width: 200000
, val:  45, goal: 178, elapsed: 5.040808, width: 200000.000000, size: 5, leaves: 1396658
val: 46
, cutoff: 66, high: 70, width: 200000
, val:  46, goal: 178, elapsed: 4.405509, width: 200000.000000, size: 5, leaves: 1328390
val: 47
, cutoff: 66, high: 70, width: 200000
, val:  47, goal: 178, elapsed: 3.881761, width: 200000.000000, size: 5, leaves: 1255598
val: 48
, cutoff: 66, high: 70, width: 200000
, val:  48, goal: 178, elapsed: 3.565578, width: 200000.000000, size: 5, leaves: 1189616
val: 49
, cutoff: 66, high: 70, width: 200000
, val:  49, goal: 178, elapsed: 3.182935, width: 200000.000000, size: 5, leaves: 1154017
val: 50
, cutoff: 67, high: 70, width: 200000
, val:  50, goal: 178, elapsed: 2.923430, width: 200000.000000, size: 5, leaves: 1112480
val: 51
, cutoff: 67, high: 70, width: 200000
, val:  51, goal: 178, elapsed: 2.716533, width: 200000.000000, size: 5, leaves: 1060403
val: 52
, cutoff: 67, high: 70, width: 200000
, val:  52, goal: 178, elapsed: 2.431757, width: 200000.000000, size: 5, leaves: 995611
val: 53
, cutoff: 67, high: 70, width: 200000
, val:  53, goal: 178, elapsed: 2.303309, width: 200000.000000, size: 5, leaves: 940084
val: 54
, cutoff: 67, high: 70, width: 200000
, val:  54, goal: 178, elapsed: 2.057869, width: 200000.000000, size: 5, leaves: 893854
val: 55
, cutoff: 68, high: 70, width: 200000
, val:  55, goal: 178, elapsed: 1.900154, width: 200000.000000, size: 5, leaves: 844029
val: 56
, cutoff: 68, high: 70, width: 200000
, val:  56, goal: 178, elapsed: 1.682282, width: 200000.000000, size: 5, leaves: 785682
val: 57
, cutoff: 68, high: 70, width: 200000
, val:  57, goal: 178, elapsed: 1.504350, width: 200000.000000, size: 5, leaves: 735189
val: 58
, cutoff: 68, high: 70, width: 200000
, val:  58, goal: 178, elapsed: 1.406517, width: 200000.000000, size: 5, leaves: 678355
val: 59
, cutoff: 68, high: 70, width: 200000
, val:  59, goal: 178, elapsed: 1.296461, width: 200000.000000, size: 5, leaves: 626083
val: 60
, cutoff: 68, high: 70, width: 200000
, val:  60, goal: 178, elapsed: 1.205203, width: 200000.000000, size: 5, leaves: 595593
val: 61
, cutoff: 68, high: 70, width: 200000
, val:  61, goal: 178, elapsed: 1.098613, width: 200000.000000, size: 5, leaves: 559811
val: 62
, cutoff: 68, high: 70, width: 200000
, val:  62, goal: 178, elapsed: 0.993093, width: 200000.000000, size: 5, leaves: 523687
val: 63
, cutoff: 68, high: 70, width: 200000
, val:  63, goal: 178, elapsed: 0.989547, width: 200000.000000, size: 5, leaves: 569631
val: 64
, cutoff: 69, high: 70, width: 200000
, val:  64, goal: 178, elapsed: 0.921962, width: 200000.000000, size: 5, leaves: 532047
val: 65
, cutoff: 69, high: 70, width: 200000
, val:  65, goal: 178, elapsed: 0.784036, width: 200000.000000, size: 5, leaves: 481182
val: 66
, cutoff: 69, high: 70, width: 200000
, val:  66, goal: 178, elapsed: 0.687100, width: 200000.000000, size: 5, leaves: 391595
val: 67
, cutoff: 69, high: 72, width: 200000
, val:  67, goal: 178, elapsed: 0.574615, width: 200000.000000, size: 5, leaves: 300530
val: 68
, cutoff: 69, high: 72, width: 200000
, val:  68, goal: 178, elapsed: 0.518417, width: 200000.000000, size: 5, leaves: 237373
val: 69
, cutoff: 0, high: 72, width: 200000
, val:  69, goal: 178, elapsed: 0.436965, width: 200000.000000, size: 5, leaves: 43934
val: 70
, cutoff: 0, high: 72, width: 200000
, val:  70, goal: 178, elapsed: 0.345577, width: 200000.000000, size: 5, leaves: 4
val: 71
, cutoff: 0, high: 72, width: 200000
, val:  71, goal: 178, elapsed: 0.112045, width: 200000.000000, size: 5, leaves: 2
val: 72
, val:  72, goal: 178, elapsed: 0.026074, width: 200000.000000, size: 5, leaves: 0
val: 2
, cutoff: 0, high: 72, width: 100000000
, val:   2, goal: 178, elapsed: 0.027072, width: 100000000.000000, size: 1, leaves: 24
val: 3
, cutoff: 0, high: 72, width: 100000000
, val:   3, goal: 178, elapsed: 0.028907, width: 100000000.000000, size: 1, leaves: 274
val: 4
, cutoff: 0, high: 72, width: 100000000
, val:   4, goal: 178, elapsed: 0.035243, width: 100000000.000000, size: 1, leaves: 1985
val: 5
, cutoff: 0, high: 72, width: 100000000
, val:   5, goal: 178, elapsed: 0.069897, width: 100000000.000000, size: 1, leaves: 10268
val: 6
, cutoff: 0, high: 72, width: 100000000
, val:   6, goal: 178, elapsed: 0.140995, width: 100000000.000000, size: 1, leaves: 40460
val: 7
, cutoff: 0, high: 72, width: 100000000
, val:   7, goal: 178, elapsed: 0.310796, width: 100000000.000000, size: 1, leaves: 126593
val: 8
, cutoff: 0, high: 72, width: 100000000
, val:   8, goal: 178, elapsed: 0.731564, width: 100000000.000000, size: 1, leaves: 324236
val: 9
, cutoff: 0, high: 72, width: 100000000
, val:   9, goal: 178, elapsed: 1.582310, width: 100000000.000000, size: 1, leaves: 697784
val: 10
, cutoff: 0, high: 72, width: 100000000
, val:  10, goal: 178, elapsed: 3.185773, width: 100000000.000000, size: 1, leaves: 1296053
val: 11
, cutoff: 0, high: 72, width: 100000000
, val:  11, goal: 178, elapsed: 6.066430, width: 100000000.000000, size: 2, leaves: 2145772
val: 12
, cutoff: 0, high: 72, width: 100000000
, val:  12, goal: 178, elapsed: 8.587998, width: 100000000.000000, size: 3, leaves: 3307085
val: 13
, cutoff: 0, high: 72, width: 100000000
, val:  13, goal: 178, elapsed: 11.532041, width: 100000000.000000, size: 4, leaves: 5046636
val: 14
, cutoff: 0, high: 72, width: 100000000
, val:  14, goal: 178, elapsed: 17.132826, width: 100000000.000000, size: 8, leaves: 8302390
val: 15
, cutoff: 0, high: 72, width: 100000000
, val:  15, goal: 178, elapsed: 24.827206, width: 100000000.000000, size: 14, leaves: 16177005
val: 16
, cutoff: 0, high: 72, width: 100000000
, val:  16, goal: 178, elapsed: 60.684776, width: 100000000.000000, size: 28, leaves: 39639081
val: 17
, cutoff: 19, high: 72, width: 100000000
, val:  17, goal: 178, elapsed: 208.959549, width: 100000000.000000, size: 73, leaves: 122049958
val: 18
, cutoff: 50, high: 72, width: 100000000
, val:  18, goal: 178, elapsed: 728.108826, width: 100000000.000000, size: 245, leaves: 446757149
val: 19
, cutoff: 53, high: 71, width: 100000000
, val:  19, goal: 178, elapsed: 1093.453735, width: 100000000.000000, size: 305, leaves: 554102684
val: 20
, cutoff: 55, high: 71, width: 100000000
, val:  20, goal: 178, elapsed: 1255.504883, width: 100000000.000000, size: 333, leaves: 600871169
val: 21
, cutoff: 56, high: 71, width: 100000000
, val:  21, goal: 178, elapsed: 1383.793823, width: 100000000.000000, size: 355, leaves: 641851131
val: 22
, cutoff: 57, high: 74, width: 100000000
, val:  22, goal: 178, elapsed: 1426.068359, width: 100000000.000000, size: 374, leaves: 672453019
val: 23
, cutoff: 57, high: 74, width: 100000000
, val:  23, goal: 178, elapsed: 1431.605591, width: 100000000.000000, size: 383, leaves: 685948510
val: 24
, cutoff: 58, high: 72, width: 100000000
, val:  24, goal: 178, elapsed: 1461.121460, width: 100000000.000000, size: 389, leaves: 691801454
val: 25
, cutoff: 59, high: 72, width: 100000000
, val:  25, goal: 178, elapsed: 1456.439575, width: 100000000.000000, size: 394, leaves: 696124204
val: 26
, cutoff: 59, high: 73, width: 100000000
, val:  26, goal: 178, elapsed: 1465.199707, width: 100000000.000000, size: 400, leaves: 704664305
val: 27
, cutoff: 60, high: 72, width: 100000000
, val:  27, goal: 178, elapsed: 1384.834717, width: 100000000.000000, size: 401, leaves: 699013654
val: 28
, cutoff: 60, high: 71, width: 100000000
, val:  28, goal: 178, elapsed: 1396.545410, width: 100000000.000000, size: 413, leaves: 718986588
val: 29
, cutoff: 61, high: 72, width: 100000000
, val:  29, goal: 178, elapsed: 1354.277466, width: 100000000.000000, size: 414, leaves: 716063603
val: 30
, cutoff: 61, high: 72, width: 100000000
, val:  30, goal: 178, elapsed: 1332.884766, width: 100000000.000000, size: 422, leaves: 727120224
val: 31
, cutoff: 62, high: 72, width: 100000000
, val:  31, goal: 178, elapsed: 1281.899780, width: 100000000.000000, size: 427, leaves: 726749769
val: 32
, cutoff: 62, high: 72, width: 100000000
, val:  32, goal: 178, elapsed: 1233.166504, width: 100000000.000000, size: 427, leaves: 728090120
val: 33
, cutoff: 62, high: 74, width: 100000000
, val:  33, goal: 178, elapsed: 1183.838623, width: 100000000.000000, size: 437, leaves: 736779898
val: 34
, cutoff: 63, high: 72, width: 100000000
, val:  34, goal: 178, elapsed: 1160.547974, width: 100000000.000000, size: 445, leaves: 753589672
val: 35
, cutoff: 63, high: 74, width: 100000000
, val:  35, goal: 178, elapsed: 1134.852417, width: 100000000.000000, size: 458, leaves: 767133763
val: 36
, cutoff: 63, high: 74, width: 100000000
, val:  36, goal: 178, elapsed: 1088.442139, width: 100000000.000000, size: 459, leaves: 758336298
val: 37
, cutoff: 64, high: 74, width: 100000000
, val:  37, goal: 178, elapsed: 1020.969238, width: 100000000.000000, size: 451, leaves: 748206896
val: 38
, cutoff: 64, high: 74, width: 100000000
, val:  38, goal: 178, elapsed: 974.424133, width: 100000000.000000, size: 457, leaves: 740994669
val: 39
, cutoff: 64, high: 74, width: 100000000
, val:  39, goal: 178, elapsed: 911.861328, width: 100000000.000000, size: 458, leaves: 733408719
val: 40
, cutoff: 65, high: 74, width: 100000000
, val:  40, goal: 178, elapsed: 862.216919, width: 100000000.000000, size: 453, leaves: 726122995
val: 41
, cutoff: 65, high: 74, width: 100000000
, val:  41, goal: 178, elapsed: 791.593201, width: 100000000.000000, size: 448, leaves: 715901019
val: 42
, cutoff: 65, high: 74, width: 100000000
, val:  42, goal: 178, elapsed: 737.696594, width: 100000000.000000, size: 451, leaves: 703200309
val: 43
, cutoff: 65, high: 74, width: 100000000
, val:  43, goal: 178, elapsed: 685.420410, width: 100000000.000000, size: 447, leaves: 684284334
val: 44
, cutoff: 66, high: 74, width: 100000000
, val:  44, goal: 178, elapsed: 637.482788, width: 100000000.000000, size: 438, leaves: 666367811
val: 45
, cutoff: 66, high: 74, width: 100000000
, val:  45, goal: 178, elapsed: 589.016479, width: 100000000.000000, size: 428, leaves: 650766028
val: 46
, cutoff: 66, high: 74, width: 100000000
, val:  46, goal: 178, elapsed: 553.707214, width: 100000000.000000, size: 431, leaves: 635446061
val: 47
, cutoff: 66, high: 74, width: 100000000
, val:  47, goal: 178, elapsed: 508.599243, width: 100000000.000000, size: 427, leaves: 613743944
val: 48
, cutoff: 66, high: 74, width: 100000000
, val:  48, goal: 178, elapsed: 470.440125, width: 100000000.000000, size: 418, leaves: 594795812
val: 49
, cutoff: 67, high: 75, width: 100000000
, val:  49, goal: 178, elapsed: 432.396851, width: 100000000.000000, size: 407, leaves: 571833437
val: 50
, cutoff: 67, high: 76, width: 100000000
, val:  50, goal: 178, elapsed: 394.351349, width: 100000000.000000, size: 394, leaves: 550446632
val: 51
, cutoff: 67, high: 77, width: 100000000
, val:  51, goal: 178, elapsed: 359.097656, width: 100000000.000000, size: 390, leaves: 524741436
val: 52
, cutoff: 67, high: 77, width: 100000000
, val:  52, goal: 178, elapsed: 327.818665, width: 100000000.000000, size: 384, leaves: 496529536
val: 53
, cutoff: 67, high: 77, width: 100000000
, val:  53, goal: 178, elapsed: 298.114288, width: 100000000.000000, size: 371, leaves: 468888824
val: 54
, cutoff: 68, high: 77, width: 100000000
, val:  54, goal: 178, elapsed: 268.220490, width: 100000000.000000, size: 358, leaves: 443654081
val: 55
, cutoff: 68, high: 79, width: 100000000
, val:  55, goal: 178, elapsed: 241.307373, width: 100000000.000000, size: 344, leaves: 421620693
val: 56
, cutoff: 68, high: 79, width: 100000000
, val:  56, goal: 178, elapsed: 217.504974, width: 100000000.000000, size: 343, leaves: 396972101
val: 57
, cutoff: 68, high: 79, width: 100000000
, val:  57, goal: 178, elapsed: 197.574524, width: 100000000.000000, size: 340, leaves: 372492991
val: 58
, cutoff: 68, high: 79, width: 100000000
, val:  58, goal: 178, elapsed: 178.964905, width: 100000000.000000, size: 335, leaves: 347943555
val: 59
, cutoff: 68, high: 79, width: 100000000
, val:  59, goal: 178, elapsed: 162.856781, width: 100000000.000000, size: 331, leaves: 326371113
val: 60
, cutoff: 68, high: 79, width: 100000000
, val:  60, goal: 178, elapsed: 147.895432, width: 100000000.000000, size: 324, leaves: 306755054
val: 61
, cutoff: 68, high: 79, width: 100000000
, val:  61, goal: 178, elapsed: 133.901596, width: 100000000.000000, size: 320, leaves: 289681318
val: 62
, cutoff: 68, high: 79, width: 100000000
, val:  62, goal: 178, elapsed: 122.079254, width: 100000000.000000, size: 315, leaves: 275034835
val: 63
, cutoff: 69, high: 79, width: 100000000
, val:  63, goal: 178, elapsed: 109.798050, width: 100000000.000000, size: 313, leaves: 259471373
val: 64
, cutoff: 69, high: 79, width: 100000000
, val:  64, goal: 178, elapsed: 98.214180, width: 100000000.000000, size: 316, leaves: 238277868
val: 65
, cutoff: 69, high: 79, width: 100000000
, val:  65, goal: 178, elapsed: 87.769577, width: 100000000.000000, size: 319, leaves: 216196341
val: 66
, cutoff: 69, high: 79, width: 100000000
, val:  66, goal: 178, elapsed: 77.576912, width: 100000000.000000, size: 321, leaves: 196968348
val: 67
, cutoff: 69, high: 79, width: 100000000
, val:  67, goal: 178, elapsed: 68.305817, width: 100000000.000000, size: 318, leaves: 178771512
val: 68
, cutoff: 69, high: 79, width: 100000000
, val:  68, goal: 178, elapsed: 57.483017, width: 100000000.000000, size: 300, leaves: 139606357
val: 69
, cutoff: 0, high: 79, width: 100000000
, val:  69, goal: 178, elapsed: 45.959084, width: 100000000.000000, size: 242, leaves: 50092709
val: 70
, cutoff: 0, high: 79, width: 100000000
, val:  70, goal: 178, elapsed: 34.614437, width: 100000000.000000, size: 112, leaves: 11828916
val: 71
, cutoff: 0, high: 79, width: 100000000
, val:  71, goal: 178, elapsed: 15.144011, width: 100000000.000000, size: 32, leaves: 2381692
val: 72
, cutoff: 0, high: 79, width: 100000000
, val:  72, goal: 178, elapsed: 3.870615, width: 100000000.000000, size: 8, leaves: 444085
val: 73
, cutoff: 0, high: 79, width: 100000000
, val:  73, goal: 178, elapsed: 0.885398, width: 100000000.000000, size: 8, leaves: 99380
val: 74
, cutoff: 0, high: 79, width: 100000000
, val:  74, goal: 178, elapsed: 0.286789, width: 100000000.000000, size: 8, leaves: 41460
val: 75
, cutoff: 0, high: 79, width: 100000000
, val:  75, goal: 178, elapsed: 0.077709, width: 100000000.000000, size: 8, leaves: 17340
val: 76
, cutoff: 0, high: 79, width: 100000000
, val:  76, goal: 178, elapsed: 0.031454, width: 100000000.000000, size: 7, leaves: 6556
val: 77
, cutoff: 0, high: 79, width: 100000000
, val:  77, goal: 178, elapsed: 0.027914, width: 100000000.000000, size: 7, leaves: 1572
val: 78
, cutoff: 0, high: 79, width: 100000000
, val:  78, goal: 178, elapsed: 0.027548, width: 100000000.000000, size: 7, leaves: 384
val: 79
, val:  79, goal: 178, elapsed: 0.027865, width: 100000000.000000, size: 6, leaves: 0
val: 2
, cutoff: 0, high: 58, width: 100000000
, val:   2, goal: 178, elapsed: 0.024842, width: 100000000.000000, size: 1, leaves: 24
val: 3
, cutoff: 0, high: 57, width: 100000000
, val:   3, goal: 178, elapsed: 0.023749, width: 100000000.000000, size: 1, leaves: 274
val: 4
, cutoff: 0, high: 58, width: 100000000
, val:   4, goal: 178, elapsed: 0.031055, width: 100000000.000000, size: 1, leaves: 1985
val: 5
, cutoff: 0, high: 58, width: 100000000
, val:   5, goal: 178, elapsed: 0.048898, width: 100000000.000000, size: 1, leaves: 10268
val: 6
, cutoff: 0, high: 59, width: 100000000
, val:   6, goal: 178, elapsed: 0.138701, width: 100000000.000000, size: 1, leaves: 40460
val: 7
, cutoff: 0, high: 60, width: 100000000
, val:   7, goal: 178, elapsed: 0.288101, width: 100000000.000000, size: 1, leaves: 126593
val: 8
, cutoff: 0, high: 61, width: 100000000
, val:   8, goal: 178, elapsed: 0.669363, width: 100000000.000000, size: 1, leaves: 324236
val: 9
, cutoff: 0, high: 61, width: 100000000
, val:   9, goal: 178, elapsed: 1.556945, width: 100000000.000000, size: 1, leaves: 697784
val: 10
, cutoff: 0, high: 61, width: 100000000
, val:  10, goal: 178, elapsed: 3.236647, width: 100000000.000000, size: 1, leaves: 1296053
val: 11
, cutoff: 0, high: 62, width: 100000000
, val:  11, goal: 178, elapsed: 5.991817, width: 100000000.000000, size: 2, leaves: 2145772
val: 12
, cutoff: 0, high: 62, width: 100000000
, val:  12, goal: 178, elapsed: 8.393559, width: 100000000.000000, size: 3, leaves: 3307085
val: 13
, cutoff: 0, high: 64, width: 100000000
, val:  13, goal: 178, elapsed: 11.343548, width: 100000000.000000, size: 4, leaves: 5046636
val: 14
, cutoff: 0, high: 64, width: 100000000
, val:  14, goal: 178, elapsed: 15.944761, width: 100000000.000000, size: 8, leaves: 8302390
val: 15
, cutoff: 0, high: 64, width: 100000000
, val:  15, goal: 178, elapsed: 22.891436, width: 100000000.000000, size: 14, leaves: 16177005
val: 16
, cutoff: 0, high: 66, width: 100000000
, val:  16, goal: 178, elapsed: 54.897835, width: 100000000.000000, size: 28, leaves: 39639081
val: 17
, cutoff: 19, high: 66, width: 100000000
, val:  17, goal: 178, elapsed: 178.665146, width: 100000000.000000, size: 75, leaves: 122049958
val: 18
, cutoff: 49, high: 67, width: 100000000
, val:  18, goal: 178, elapsed: 617.770691, width: 100000000.000000, size: 247, leaves: 447151589
val: 19
, cutoff: 52, high: 68, width: 100000000
, val:  19, goal: 178, elapsed: 880.143799, width: 100000000.000000, size: 292, leaves: 529610997
val: 20
, cutoff: 54, high: 68, width: 100000000
, val:  20, goal: 178, elapsed: 951.771118, width: 100000000.000000, size: 313, leaves: 557396566
val: 21
, cutoff: 55, high: 68, width: 100000000
, val:  21, goal: 178, elapsed: 1023.323975, width: 100000000.000000, size: 330, leaves: 582640489
val: 22