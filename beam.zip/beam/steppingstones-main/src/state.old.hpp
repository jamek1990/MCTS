#pragma once
#include "header.hpp"
const int MAX_GOAL  = 200;

enum Variant { T5 = 0, D5 = 1 };
int variant = T5;
const int _SIZE = 40;
typedef int Direction;
typedef int Position;
static const int DIRS = 4;
static const int ARRAY__SIZE = _SIZE * _SIZE;
static const int LINE = 5;
const int dir[DIRS] = {1, _SIZE + 1, _SIZE, _SIZE - 1};
static const int CODES = 6400*5;//00;
int dir_dot[ARRAY__SIZE];
bool is_seq[CODES];
bool records[CODES];
bool max_records[CODES];
int max_record = 0;
double avg_code[CODES];
double state_code[CODES];
double action_code[CODES];
int init_move = 1;
int max_init_size = 0;
        bool visit[CODES];

int SEQ[3][2000*40][10];
int SEQ_SIZE[3][2000*40];
int SEQ_SCORE[3][2000*40];
int SEQ_OLD[3][2000*40][10];
int SEQ_OLD_SCORE[3][2000*40];
int SEQ_OLD_SIZE[3][2000*40];

int PREV = true;
int max_legal_move_size = 0;
int nr_layer_172[174]= {
//0,0,0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 11, 11, 12, 12, 13, 13, 13, 14, 14, 15, 15, 15, 15, 16, 16, 16, 16, 16, 16, 17, 17, 17, 17, 18, 18, 18, 19, 19, 20, 20, 20, 20, 21, 21, 21, 21, 21, 21, 22, 22, 22, 22, 23, 23, 23, 23, 23, 24, 24, 25, 25, 25, 26, 26, 26, 27, 27, 27, 27, 28, 28, 28, 28, 29, 29, 29, 30, 30, 31, 31, 32, 32, 33, 33, 33, 34, 34, 35, 35, 35, 36, 36, 36, 36, 37, 37, 38, 38, 39, 40, 40, 41, 41, 42, 43, 44, 45, 45, 45, 46, 46, 46, 47, 47, 47, 47, 48, 48, 48, 48, 49, 49, 49, 49, 50, 50, 51, 51, 51, 52, 52, 53, 54, 54, 55, 56, 56, 57, 57, 58, 58, 59, 59, 60, 61, 61, 62, 63, 64, 64, 65, 65, 66, 67, 68, 69, 69, 70, 71
  0,0,0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 11, 11, 12, 12, 13, 13, 13, 14, 14, 15, 15, 15, 15, 16, 16, 16, 16, 16, 16, 17, 17, 17, 17, 18, 18, 18, 19, 19, 20, 20, 20, 20, 21, 21, 21, 21, 21, 21, 22, 22, 22, 22, 23, 23, 23, 23, 23, 24, 24, 25, 25, 25, 26, 26, 26, 27, 27, 27, 27, 28, 28, 28, 28, 29, 29, 29, 30, 30, 31, 31, 32, 32, 33, 33, 33, 34, 34, 35, 35, 35, 36, 36, 36, 36, 37, 37, 38, 38, 39, 40, 40, 41, 41, 42, 43, 44, 45, 45, 45, 46, 46, 46, 47, 47, 47, 47, 48, 48, 48, 48, 49, 49, 49, 49, 50, 50, 51, 51, 51, 52, 52, 53, 54, 54, 55, 56, 56, 57, 57, 58, 58, 59, 59, 60, 61, 61, 62, 63, 64, 64, 65, 65, 66, 67, 68, 69, 69, 70, 71
};
int nr_layer_178[180]= {
0,0,
0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 11, 11, 12, 12, 13, 13, 13, 14, 14, 15, 15, 15, 15, 16, 16, 16, 16, 16, 16, 17, 17, 17, 17, 18, 18, 18, 19, 19, 19, 19, 20, 20, 20, 20, 21, 21, 21, 22, 22, 22, 22, 23, 23, 23, 23, 23, 24, 24, 24, 25, 25, 25, 25, 26, 26, 26, 27, 27, 28, 28, 28, 29, 29, 30, 31, 32, 33, 33, 34, 34, 35, 35, 35, 35, 36, 36, 36, 37, 37, 37, 38, 38, 38, 39, 39, 39, 40, 40, 40, 41, 42, 43, 43, 43, 44, 44, 44, 44, 45, 45, 45, 45, 46, 46, 46, 46, 47, 47, 47, 48, 48, 48, 48, 48, 49, 50, 51, 51, 52, 53, 53, 54, 54, 54, 55, 55, 56, 57, 58, 58, 59, 59, 60, 61, 61, 62, 62, 63, 63, 64, 64, 65, 65, 66, 67, 67, 68, 68, 69, 69, 70, 70, 71, 71, 72
};
int nr_hole_172[174] = {

0,0,0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10
};

int nr_hole_178[180] = {

0,0,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7
};

int nr_square_172[174] = {
  0,0,0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 4, 5, 6, 6, 8, 8, 11, 11, 12, 14, 16, 18, 19, 19, 19, 19, 20, 21, 23, 23, 23, 24, 25, 25, 25, 27, 27, 28, 29, 30, 31, 33, 35, 35, 38, 38, 41, 41, 42, 44, 44, 45, 48, 50, 50, 51, 51, 52, 52, 53, 53, 53, 54, 55, 59, 59, 61, 61, 61, 62, 62, 64, 65, 65, 67, 67, 68, 70, 71, 71, 73, 74, 76, 77, 79, 79, 80, 83, 84, 84, 84, 86, 86, 86, 87, 89, 91, 91, 91, 92, 93, 93, 95, 95, 97, 100, 100, 101, 102, 104, 108, 109, 109, 109, 110, 111, 112, 114, 115, 115, 117, 118, 118, 120, 121, 122, 122, 123, 124, 124, 126, 126, 130, 131, 132, 133, 134, 134, 134, 136, 136, 139, 140, 140, 141, 142, 143, 145, 146, 146, 146, 147, 148, 148, 148, 150, 150, 151
};
int nr_square_178[180] = {
  0,0,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 3, 4, 4, 4, 4, 7, 11, 11, 12, 13, 15, 17, 18, 18, 19, 21, 21, 21, 21, 23, 24, 24, 26, 27, 28, 30, 30, 31, 31, 31, 32, 33, 33, 34, 38, 39, 40, 43, 43, 44, 44, 45, 47, 49, 50, 50, 50, 51, 51, 51, 53, 55, 57, 58, 60, 61, 62, 65, 65, 65, 66, 66, 67, 67, 68, 68, 70, 70, 70, 72, 73, 75, 76, 76, 77, 80, 80, 82, 82, 83, 84, 85, 86, 88, 90, 91, 92, 92, 94, 94, 95, 96, 96, 98, 99, 100, 101, 102, 104, 104, 105, 105, 105, 109, 111, 115, 115, 116, 118, 119, 119, 119, 120, 121, 122, 122, 124, 126, 126, 127, 128, 128, 129, 134, 135, 135, 136, 136, 136, 137, 137, 140, 141, 142, 142, 143, 143, 144, 145, 146, 146, 148, 149, 149, 150, 152, 153, 154, 156, 158, 159, 159, 159, 160
};

int blokuj_move[55] = {2157, 2158, 2159, 2312, 2326, 2335, 2342, 2343, 2469, 2479, 2625, 2626, 2629, 2667, 2780, 2781, 2782, 2796, 2798, 2813, 2831, 2940, 2941, 2949, 2956, 2966, 2967, 2972, 2982, 3100, 3101, 3116, 3125, 3132, 3276, 3285, 3291, 3292, 3420, 3436, 3437, 3452, 3455, 3597, 3605, 3606, 3610, 3622, 3631, 3757, 3768, 3778, 3912, 3928, 3934};

double policy[6400*5];

char dis[_SIZE*3][_SIZE*3];

long long HashArray[6400*5];
void gen_hash_array(){
  for (int i = 0; i <6400;  i++) {
    HashArray[i] = rand()*(rand ()+1);
  }
}
int min_code_valid = 0;
int max_code_valid = 0;
int max_code_valid2 = 0;
int max_code[CODES];

class Move {
public:
  Position pos;
  Direction dir;
  Move() {}
  Move(Position pos, Direction dir) : pos(pos), dir(dir) {}
};

class Undo {
public:
  Position pos;
  Move move;
  unsigned int low;
  int high;
  int hole;
  Undo() {}
  Undo(Move _move, Position _pos, int _low, int _high, int _hole)
      : move(_move), pos(_pos) {
    low = _low;
    high = _high;
    hole = _hole;
  }
};

  class Sequence {
    //static const int bound = 1000;

   public:
    unsigned int length;
    std::vector<Move> mv;
    
    Sequence() {
      init();
    }
    void init() {
      length = 0;
      mv.resize(1000);
    }
   /* Sequence& operator=(const Sequence& s) {
      length = s.length;
      memcpy(mv, s.mv, length * sizeof(Move));
      return *this;
    }*/
  };

struct LayerHist {
  int layer;
  int layer_size;
  long long layer_stop;
  int low;
  LayerHist() {}
  LayerHist(int _layer, int _layer_size, long long _layer_stop, int _low) {
    layer = _layer;
    layer_size = _layer_size;
    layer_stop = _layer_stop;
    low = _low;
  }
};

/*
  void SEQ_UPDATE(bool(&seq_code)[200]) {
    state st;
  }
*/

struct state {
LayerHist layer_hist[1000];
int layer_size = 0;
int layer_stop = 0;
Undo history[2000];
int history_size = 0;


 protected:
  enum { RIGHT = 0,
         DOWN = 2,
         LEFT = 4,
         UP = 6 };

  bool has_dot[ARRAY__SIZE];
  int dots_count[ARRAY__SIZE][DIRS];
  bool is_line[ARRAY__SIZE][DIRS];
  int square_count[ARRAY__SIZE];
 
  
  public:
  int bad_count = 0;
  int square = 0;
  Sequence legal_moves;
  Sequence legal_moves2;

  pair<int,int> t_right_length[200];
  Move t_right[2000];
  int t_right_size = 0;


  int seq_code[200];
  int score = 0;
  int length = 0;
  int best_seq_length = 0;
  int best_seq[200];
  int hole = 0;
  unsigned int low = 0;
  int bottom = 0;
  long long hash = 0;

  state() {
    reset(0);
  }


  inline Position PositionOfCoords(int x, int y) const {
    return x + y * _SIZE;
  }

  int ShiftFromDir(int d) { return d < DIRS ? dir[d] : -dir[d - DIRS]; }
  void blokuj() {
    FOR(i,55){
      int d = blokuj_move[i]%4;
      int pos = (blokuj_move[i]-d)/4;
      for (int i =LINE - 2  ; i >= -(LINE - 2); i--)
        if(i!=0)
          dots_count[pos + dir[d] * i][d] += LINE;
    }
  }
  void reset(int ini = 5) {
    memset(has_dot, 0, sizeof(has_dot));
    memset(dots_count, 0, sizeof(dots_count));
    memset(is_line, false, sizeof(is_line));
    memset(square_count, 0, sizeof(square_count));
    square = 0;
    low = 0;
    legal_moves.init();
    legal_moves2.init();
    static const int cross[] = {
        RIGHT, UP, RIGHT, DOWN, RIGHT, DOWN, LEFT, DOWN, LEFT, UP, LEFT, UP};
    static const int ARMLEN = LINE - 2;
    Position p =
        PositionOfCoords((_SIZE - 3 * ARMLEN) / 2,
                         (_SIZE - ARMLEN) / 2);
    for (int i = 0; i < 12; i++) {
      int d = ShiftFromDir(cross[i]);
      for (int j = 0; j < ARMLEN; j++) {
        p += d;
        PutDot(p, 1);
      }
    }
     history_size = 0;
    low = 0;
    bottom = legalMoves()-1;
    score = 0;
    hole = 0;
    hash = 0;

 //  blokuj();
   // if(CanMove(legal_moves.mv[0].pos,legal_moves.mv[0].dir)) {
   //do_move(low);
    //}
 //   /*if(CanMove(legal_moves.mv[low].pos,legal_moves.mv[low].dir)) {
   // do_move(low);
   // }*/
   
    
    //next_move();
    layer_size = 0;
    layer_stop = legalMoves();

    layer_hist[score].layer = 0;
    layer_hist[score].layer_size = 0;
    layer_hist[score].layer_stop = 0;
    layer_hist[score].low = 0;


    //do_move(0);
    nextMove();
     init(ini);
  }


  bool CanMove(Position pos, Direction d, bool opt = false) const {
   // opt = false;
     return dots_count[pos][d] == LINE - 1;
  }



  bool IncDotCount(Position pos, Direction d, int count, bool t = true) {
    dots_count[pos][d] += count;
    
    if (CanMove(pos, d)) {
      if(t){
        legal_moves.mv[legal_moves.length].dir = d;
        legal_moves.mv[legal_moves.length++].pos = pos;
        if(PREV){
          legal_moves2.mv[legal_moves2.length].dir = d;
          legal_moves2.mv[legal_moves2.length++].pos = pos;
          bottom = legal_moves2.length-1;
        }
      }else{

     //  cout<<"f";false
      }
      return true;
      
    }
    return false;
  }
   void IncDotCountUndo(Position pos, Direction d, int count) {
    dots_count[pos][d] += count;
   }

  void PutDot(Position pos, int count) {
    has_dot[pos] = count > 0;
    for (Direction d = 0; d < DIRS; d++)
    {
        Position p = pos;
        bool t= true;
        if(is_line[p+4*dir[d]][d]) {
          for (int i = 0; i < LINE; i++)
          {
            if(is_line[p+4*dir[d]][d]){
              if(IncDotCount(p, d, count,t))
                t = true;//(variant_game==0);
            }else{
              IncDotCount(p, d, count,t);
            }
            p -= dir[d];
          }
        } else if(is_line[p-5*dir[d]][d]) {
          p -= dir[d]*(LINE-1);
          for (int i = 0; i < LINE; i++)
          {
            if(is_line[p-dir[d]][d]){
              if(IncDotCount(p, d, count,1)){
                t =true;//(variant_game==0);
              }
            }else{
              IncDotCount(p, d, count,t);
            }
            p += dir[d];
          }
       
       } else {
          for (int i = 0; i < LINE; i++) {
            IncDotCount(p, d, count);
            p -= dir[d];
          }
        }/* else {
          p -= dir[d]*(LINE-1);
          for (int i = 0; i < LINE; i++)
          {
            if(is_line[p-dir[d]][d]){
              if(IncDotCount(p, d, count,t)){
                t = (variant_game==1);
              }
            }else{
              IncDotCount(p, d, count,t);
            }
            p += dir[d];
          }
        }*/ 
    }
  }

  void PutDotUndo(Position pos, int count) {
    has_dot[pos] = count > 0;
    for (Direction d = 0; d < DIRS; d++) {
      Position p = pos;
      for (int i = 0; i < LINE; i++) {
        IncDotCountUndo(p, d, count);
        p -= dir[d];
      }
    }
  }

  int count_hole(const Move & m) {
    int _hole = 0;
    int tmp = 0;
    for (int i = 0; i < LINE-1; i++) {
      Position p = m.pos - dir[m.dir]*(i+1);
      if(is_line[p][m.dir]){
        _hole += tmp;
        break;
      } else {
        tmp++;
      }
    }
    tmp = 0;
    for (int i = 0; i < LINE-1; i++) {
      Position p = m.pos + dir[m.dir]*(LINE-1+i);
      if(is_line[p][m.dir]){
        _hole += tmp;
        break;
      } else {
        tmp++;
      }
    }
    return _hole;
  }

  //const int dir[DIRS] = {1, _SIZE + 1, _SIZE, _SIZE - 1};


  void add_squre(Move move){
    for (int i = 0; i < LINE; i++) {
      Position p = move.pos + dir[move.dir] * i;
      if(move.dir == 0) {
        square_count[p]++;
        if(square_count[p]==6)square++;
        square_count[p-_SIZE]++;
        if(square_count[p-_SIZE]==6)square++;
      } else if(move.dir == 1) {
        square_count[p]++;
        if(square_count[p]==6)square++;
      } else if(move.dir == 2) {
        square_count[p]++;
        if(square_count[p]==6)square++;
        square_count[p-1]++;
        if(square_count[p-1]==6)square++;
      } else if(move.dir == 3) {
        square_count[p-1]++;
        if(square_count[p-1]==6)square++;
      }
    }
  }

  void undo_square(Move move){
    for (int i = 0; i < LINE; i++) {
      Position p = move.pos + dir[move.dir] * i;
      if(move.dir == 0) {
        if(square_count[p]==6)square--;
        square_count[p]--;
        if(square_count[p-_SIZE]==6)square--;
        square_count[p-_SIZE]--;
      } else if(move.dir == 1) {
        if(square_count[p]==6)square--;
        square_count[p]--;
      } else if(move.dir == 2) {
        if(square_count[p]==6)square--;
        square_count[p]--;
        if(square_count[p-1]==6)square--;
        square_count[p-1]--;
        
      } else if(move.dir == 3) {
        if(square_count[p-1]==6)square--;
        square_count[p-1]--;
      }
    }
  }

  int delta_square(Move move) {
    int delta = square;
    add_squre(move);
    delta = square - delta;
    undo_square(move);
    return delta;
  }

  void do_move(int nr,bool next, int pre ) {
   // low = nr;
    Move move;
    if(!PREV){
      move = legal_moves.mv[nr];
    }else{
      move = legal_moves2.mv[nr];

      t_right_length[score].first =legal_moves2.length-nr;
      t_right_length[score].second =legal_moves2.length;
      FORD(i,legal_moves2.length-1,nr){
        t_right[t_right_size++] = legal_moves2.mv[i];
      }
      legal_moves2.length = nr;
      t_right_length[score].second =legal_moves2.length;
      bottom = nr -1;
    }

    if(!records[code(move)])bad_count++;
    if(!CanMove(move.pos,move.dir)){
      cout<<"!CanMove BLAD\n";
      low = nr+1;
     // return;
      int hy;cin>>hy;
    }
    hash^=HashArray[code(move)];
    seq_code[score]=code(move);
    score++;
    length++;
    best_seq[best_seq_length++]=nr;
    //cout<<"move code: "<<code(move)<<"\n";
    

    int _high = legal_moves.length;
    int _low = low;
    int old_legal_moves = legalMoves();
    for (int i = -(LINE - 2 + variant); i <= LINE - 2 + variant; i++)
      IncDotCount(move.pos + dir[move.dir] * i, move.dir, LINE,true);
    for (int i = 0; i < LINE; i++) {
      Position p = move.pos + dir[move.dir] * i;
      if(i!=LINE-1)
        is_line[p][move.dir]=true;
    }
   
    for (int i = 0; i < LINE; i++) {
      Position p = move.pos + dir[move.dir] * i;
      if (!has_dot[p]) {
        dir_dot[p]=move.dir;
        PutDot(p, 1);
        
        history[history_size++] = Undo(move,p,_low,_high, hole);
        hole += count_hole(move);
        break;
      }
    }
    
    if(PREV)
      bottom = legal_moves2.length-1;
  }
  bool is_connect(Move m) {
    int pos = m.pos + dir[m.dir] * -1;
    int d = m.dir;
    if(dots_count[pos][d] == 9)
      return true;
    pos = m.pos + dir[m.dir] * LINE;
    if(dots_count[pos][d] == 9)
      return true;
    return false;
  }

  int score_position(Position p) {
    int ile = 0;
    for (Direction d = 0; d < DIRS; d++) {
      if(dots_count[p][d] == 2*LINE - 1)
        ile++;
    }
    for (Direction d = 0; d < DIRS; d++) {
      if(dots_count[p-dir[d]][d] == 2*LINE - 1)
        ile++;
    }
    return ile;
  }
 
  int score_move(Move m) {
    int ile =0;
    for (int i = 0; i < LINE; i++) {
      Position p = m.pos + dir[m.dir] * i;
      ile += score_position(p);
    }
    return ile;
  }

  void undo_move(bool opt = true) {
    Move & move = history[history_size-1].move;

    
    
    Position pos = history[history_size-1].pos;
    int _high = history[history_size-1].high;
    int _low = history[history_size-1].low;
    hole = history[history_size-1].hole;
    history_size--;
    undo_square(move);
    PutDotUndo(pos, -1);
    dir_dot[pos]=0;
    for (int i = -(LINE - 2 + variant); i <= LINE - 2 + variant; i++)
      IncDotCountUndo(move.pos + dir[move.dir] * i, move.dir, -LINE);
    for (int i = 0; i < LINE; i++) {
      Position p = move.pos + dir[move.dir] * i;
      if(i!=LINE-1)
        is_line[p][move.dir]=false;
    }
    if(!records[code(move)])bad_count--;
    legal_moves.length = _high;
    low = _low;
  //  nextMove(opt);
    score--;
    length--;
     best_seq_length--;
    if(opt){
   //   low = layer_hist[score].low;
      layer_size = layer_hist[score].layer_size;
      hash = layer_hist[score].layer_stop;
    }
    //nextMove(opt);
    if(PREV){
      legal_moves2.length = t_right_length[score].second;
      FOR(i,t_right_length[score].first){
        legal_moves2.mv[legal_moves2.length++]=t_right[--t_right_size];
      }
      bottom = legal_moves2.length-1;
    }
  }



  int fast_simple(int low_min, int low_max, int nleaf ) {
    int old = score;

    nextMove();
    while (legalMoves() > low) {
      do_move(low,true,false);
      nextMove();
    }
    int new_score = score;
    FOR(i,score){
      if(max_code[seq_code[i]]<score)
        max_code[seq_code[i]]= score;
    }
    update_seq(old,score,nleaf);
    return new_score;
  }

  int pre_fast_simple(int low_min, int low_max, int nleaf ) {
    int old = score;
    while (bottom>=0) {
      if(is_valid_move(bottom)){
        do_move(bottom,false,true);
      }else{
        bottom--;
      }
    }
    int new_score = score;
    FOR(i,score){
      if(max_code[seq_code[i]]<score)
        max_code[seq_code[i]]= score;
    }
    update_seq(old,score,nleaf);
    return new_score;
  }

  int dist_code_prob(int low_min, int low_max, int nleaf) {
    int old = score;
    int moves_length = 0;
    int moves[2000];

    nextMove();
    while(1){
      moves_length = 0;
      FORU(i,low,legalMoves()-1){
        if(is_valid_move(i,false)){
          moves[moves_length++]=i;
        }
      }
      if(moves_length==0)break;
      int min_code = 1000;
      int mm_code = 0;
      int suma = 0;
      FOR(i,moves_length){
        int nr = moves[i];
        Move move = legal_moves.mv[nr];
        int c = max_code[code(move)];
        if(c < min_code) {
          min_code = c;
        }
        if(c > mm_code) {
          mm_code = c;
        }
      }
      FOR(i,moves_length){
        int nr = moves[i];
        
        Move move = legal_moves.mv[nr];
        int c = max_code[code(move)]; 
        c = (c==0) ? mm_code : c;
        suma+=(c-(min_code-1));//*(c-(min_code-1));//*(c-(min_code-1));
      }
      
      // wybieram
      int r = rand() % (suma + 1);
      int choose = moves[0];
      suma = 0;
      FOR(i,moves_length){
        int nr = moves[i];
        Move move = legal_moves.mv[nr];
        int c = max_code[code(move)]; 
        c = (c==0) ? mm_code : c;
        suma += (c-(min_code-1));//*(c-(min_code-1));//*(c-(min_code-1));
        if(r<suma) {
          choose = nr;
          break;
        }
      }
      do_move(choose,false,false); 
    }

    int new_score = score;

   FOR(i,score){
      if(max_code[seq_code[i]]<score)
        max_code[seq_code[i]]= score;
    }

    update_seq(old,score,nleaf);

    //cout<<"new_score: "<<new_score<<"\n"; 
    return new_score;

  }
    int vis[4000];int vis_size = 0;
  int uct(double C, bool avg, int nleaf) {
    int last_code = seq_code[score-1];
    int last_length = legalMoves();
    PREV = false;
    int old = score;
    int moves_length = 0;
    int moves[2000];

    vis_size = 0;
    low = 0;

    FOR(i,score){
      visit[seq_code[i]]=true;
    }

    nextMove();





    //double C = 0.31;
    while(true) {
      moves_length = 0;
    //  cout<<"legalMoves(): "<<legalMoves()<<"\n";
      if(legalMoves() > max_legal_move_size) {
        max_legal_move_size = legalMoves();
        cout<<"max_legal_move_size: "<<max_legal_move_size<<"\n";
      }
      FORU(i,0,legalMoves()-1){
        if( visit[code(legal_moves.mv[i])])break;
        if(is_valid_move(i,false)){
          moves[moves_length++]=i;
        }
      }
      FORU(i,max(0,last_length),legalMoves()-1){
        if(is_valid_move(i,false)){
          moves[moves_length++]=i;
        }
      }
      
    if(moves_length==0)break;
      double max_c = -1.0;
      int choose = moves[0];
      int ile_ok = 0;
      FOR(i,moves_length){
        int nr = moves[i];
        if(is_valid_move(nr,false)){//} && ((ile_ok<=11 && nr <=21) || ile_ok<=7) ){
          ile_ok++;
          Move move = legal_moves.mv[nr];
          vis[vis_size++]=code(move);

          double c = (double)max_code[code(move)]/178 + C*sqrt(log(state_code[code(move)]+1.0)/(action_code[code(move)]+1.0)); 
          if(avg){
            c = (double)avg_code[code(move)]/178 + C*sqrt(log(state_code[code(move)]+1.0)/(action_code[code(move)]+1.0)); 
          }
       
          if(c > max_c) {
            max_c = c;
            choose = nr;
          }
        } else {
          moves[i] = moves[--moves_length];
          if(i!=0)
            i--;
        }
      }
      int x = legalMoves();
      do_move(choose,false,false); 
    }

    int new_score = score;

    //avg_code
    FOR(i,score){
      avg_code[seq_code[i]] = avg_code[seq_code[i]] + ((double)score-avg_code[seq_code[i]])/(state_code[seq_code[i]]+1);
    }

    FOR(i,score){
      visit[seq_code[i]]=false;
    }
    FOR(i,vis_size){
      state_code[vis[i]]++;
      
    }
    
    FOR(i,score){
      if(max_code[seq_code[i]]<score)
        max_code[seq_code[i]]= score;
      action_code[seq_code[i]]++;
    }


    update_seq(old, score, nleaf);

    
  //std::cout<<new_score<<"\n";
  PREV = true;
    return new_score;

  }

  void update_seq(int old, int old_score, int nleaf) {
    bool is_update = false;
    int seq_code_tmp[200];
    if(score > SEQ_SCORE[0][nleaf]) {
      is_update = true;
      FOR(i,old_score){
        seq_code_tmp[i]=seq_code[i];
        is_seq[seq_code[i]]=true;
      }
    }
    while(score>old){
      undo_move();
    }

    is_update = (is_update && PREV==false) && false;
    if(is_update) {

      while(low < legalMoves()){
        if(is_valid_move(low) && is_seq[code(legal_moves.mv[low])]){
          do_move(low,false,false);
        } else {
          low++;
        }
      }
      
      SEQ_SCORE[0][nleaf] = score;
      SEQ_SIZE[0][nleaf] = score-old > 10 ? 10: score-old;
      FOR(i,SEQ_SIZE[0][nleaf]){
        SEQ[0][nleaf][i]=seq_code[old+i];
      }

      if(old_score != score) {
       cout<<"BLAD";
        int y;cin>>y;
      }

      FOR(i,old_score){
        is_seq[seq_code_tmp[i]]=false;
      }

      while(score>old){
        undo_move();
      }
    }
  }

  int max_code_first(int low_min, int low_max ) {
    int old = score;
    int moves_length = 0;
    int moves[2000];

    nextMove();
    FORU(i,low,legalMoves()-1){
      if(is_valid_move(i,false)){
        moves[moves_length++]=i;
      }
    }

    while(moves_length>0) {
      //wybierz
      int max_c = -1;
      int choose = moves[0];
      FOR(i,moves_length){
        int nr = moves[i];
        if(is_valid_move(nr,false)) { 
          Move move = legal_moves.mv[nr];
          int c = max_code[code(move)]; 
          if(c > max_c) {
            max_c = c;
            choose = nr;
          }
        } else {
          moves[i] = moves[--moves_length];
          if(i!=0)
            i--;
        }
      }
      int x = legalMoves();
      do_move(choose,false,false); 
      FORU(i,x,legalMoves()-1){
        moves[moves_length++]=i;
      }
    }

    int new_score = score;

    FOR(i,score){
      if(max_code[seq_code[i]]<score)
        max_code[seq_code[i]]= score;
    }

    while(score>old){
      undo_move();
    }
  //std::cout<<new_score<<"\n";
    return new_score;
  }

  int max_code_last(int low_min, int low_max, int nleaf) {
    int old = score;
    int moves_length = 0;
    int moves[2000];

 
    while(1) {
      moves_length = 0;
      FORU(i,low,legalMoves()-1){
      if(is_valid_move(i,false)){
        moves[moves_length++]=i;
      }
    }
    if(moves_length==0)break;

      //wybierz
      int max_c = -1;
      int choose = moves[0];
      FORD(i,moves_length-1,0){
        int nr = moves[i];
        if(is_valid_move(nr,false)) { 
          Move move = legal_moves.mv[nr];
          int c = max_code[code(move)]; 
          if(c > max_c) {
            max_c = c;
            choose = nr;
          }
        } else {
          moves[i] = moves[--moves_length];
          //i++;
        }
      }
      int x = legalMoves();
      do_move(choose,false,false); 
      FORU(i,x,legalMoves()-1){
        moves[moves_length++]=i;
      }
    }

    int new_score = score;

    FOR(i,score){
      if(max_code[seq_code[i]]<score)
        max_code[seq_code[i]]= score;
    }

    update_seq(old, score, nleaf);
  //std::cout<<new_score<<"\n";
    return new_score;
  }

  int first_simple(int low_min, int low_max ) {
    int moves_last_length;
    int moves_last[2000];
    int moves_invalid[2000];
    int moves_invalid_length = 0;

    int old = score;
    nextMove();
    moves_last_length = 0;
    int v = low;
    while(1){
      if(is_valid_move(v,false)) {
        Move move = legal_moves.mv[v];
        if(max_code[code(move)] >= max_code_valid){
          do_move(v,false,false);
          v++;
        } else {
          moves_invalid[moves_invalid_length++]=v;
          v++;
        }
      } else {
         v++;
      }
      if(v>=legalMoves())break;
    }
    v = 0;
    if(moves_invalid_length>0){
      while(1){
        int nr = moves_invalid[v];
        if(is_valid_move(nr,false)) {
          int x = legalMoves();
          do_move(nr,false,false);
          v++;
          FORU(i,x,legalMoves()-1){
            moves_invalid[moves_invalid_length++]=i;
          }
        } else {
          v++;
        }
        if(v>=moves_invalid_length)break;
      }
    }
    int new_score = score;

    FOR(i,score){
      if(max_code[seq_code[i]]<score)
        max_code[seq_code[i]]= score;
    }

    while(score>old){
      undo_move();
    }
    return new_score;
  }

  
  
  int last_simple(int low_min, int low_max ) {
    int moves_last_length;
    int moves_last[2000];
    int moves_invalid[2000];
    int moves_invalid_length = 0;

    int old = score;
    nextMove();
    moves_last_length = 0;
    FORU(i,low,legalMoves()-1){
      moves_last[moves_last_length++]=i;
    }
    while(1){
     // cout<<moves_last_length<<"\n";
      int nr = moves_last[moves_last_length-1];
      if(is_valid_move(nr,false)) {
        Move move = legal_moves.mv[nr];
        if(max_code[code(move)] >= max_code_valid){
          int x = legalMoves();
          do_move(nr,false,false);
          moves_last_length--;
          FORU(i,x,legalMoves()-1){
            moves_last[moves_last_length++]=i;
          }
        } else {
          moves_invalid[moves_invalid_length++]=nr;
          moves_last_length--;
        }
      } else {
        moves_last_length--;
      }
      if(moves_last_length<=0)break;
    }
    moves_last_length = 0;
    if(moves_invalid_length>0){
      FORU(i,0,moves_invalid_length-1){
        moves_last[moves_last_length++]=moves_invalid[i];
      }
      while(1){
        int nr = moves_last[moves_last_length-1];
        if(is_valid_move(nr,false)) {
          int x = legalMoves();
          do_move(nr,false,false);
          moves_last_length--;
          FORU(i,x,legalMoves()-1){
            moves_last[moves_last_length++]=i;
          }
        } else {
          moves_last_length--;
        }
        if(moves_last_length<=0)break;
      }
    }
    int new_score = score;

    FOR(i,score){
      if(max_code[seq_code[i]]<score)
        max_code[seq_code[i]]= score;
    }

    while(score>old){
      undo_move();
    }
    return new_score;
  }

  unsigned int legalMoves() {
    return legal_moves.length;
  }
  int price() {
    int ile = 0;
    FORU(i,low,(int)legalMoves()-1){
      if(CanMove(legal_moves.mv[i].pos,legal_moves.mv[i].dir))
        ile++;
    }
    return score+ile;
  }

  void clear_rep() {
    max_record = 0;
    FOR(i,CODES)
      max_records[i]=false;
  }

  int move_score(int low_min, int low_max, int nleaf){
    return  max(uct(1.0,true, nleaf),max(uct(0.5,true, nleaf),max(uct(0.2,false, nleaf),pre_fast_simple(low_min,low_max, nleaf))));//max(uct(0.2,false, nleaf),pre_fast_simple(low_min,low_max, nleaf));//max(dist_code_prob(low_min,low_max, nleaf),max(uct(0.5,false, nleaf),max(fast_simple(low_min,low_max, nleaf),uct(0.2,false,nleaf))));//uct(0.2,false),uct(0.2,true)));//max(fast_simple(low_min,low_max),max(uct(0.2,true),max_code_last(low_min,low_max)));//max(dist_code_prob(low_min,low_max),max(max_code_last(low_min,low_max),max(max_code_first(low_min,low_max),max(fast_simple(low_min,low_max),0))));//max(dots_min_center(low_min,low_max),max(connect_last(low_min,low_max),fast_simple(low_min,low_max)));//max(play_rep_max_add(low_min,low_max),max(dots_min_center(low_min,low_max),max(connect_last(low_min,low_max),max(play_max_add(low_min,low_max),max(fast_simple(low_min,low_max), dots_center(low_min,low_max) )))));//max(dots_center(low_min,low_max),max(random_game(low_min,low_max),max(connect_first(low_min,low_max),max(fast_simple(low_min,low_max),play_max_add(low_min,low_max)))));//max(play_rep_max_add(),max(play_max_add(),max(random_game(),max(random_game(),max(random_game(),max(random_game(),max(connect_first(),max(connect_last(),fast_simple()))))))));//connect_first();// max(connect_first(),max(connect_last(),fast_simple()));
  }


  int get_score() {
    return score;
  };

  bool is_valid_move(int nr, bool ok = false) {
    Move m;
    if(PREV)
      m = legal_moves2.mv[nr];
    else
      m = legal_moves.mv[nr];
    return CanMove(m.pos,m.dir);//&& (true || hole + count_hole(m) -2<= max(nr_hole_172[score+1],nr_hole_178[score+1] ));//&& (square + delta_square(m) >= min(nr_square_172[score+1],nr_square_178[score+1]) && square + delta_square(m) <= max(nr_square_172[score+1],nr_square_178[score+1]) );//  && (layer_size + next_layer <= max(nr_layer_172[score+1],nr_layer_178[score+1]) && layer_size + next_layer >= min(nr_layer_172[score+1],nr_layer_178[score+1]))));
  }
  void nextMove(int opt = true){
    int x = low;
    while(x < legal_moves.length && !is_valid_move(x,true)) {
      x++;
    }
    low = x;
  }
 bool visit[CODES];
  void init_start(vector<int> & init_code) {   
    FOR(i,CODES)visit[i]=false;
    if(max_init_size < init_code.size()){
      max_init_size =  init_code.size();
      cout<<"--------------------------------------------------------------------------------\n";
      cout<<"max_init_size"<<max_init_size<<"\n";
    }
    FOR(i,init_code.size()){
      visit[init_code[i]]=true;
    }
    if(!PREV){
      int low_ = low;
      nextMove();
      while (legalMoves() > low) {
        if(visit[code(legal_moves.mv[low])]){
          if(code(legal_moves.mv[low])>CODES)cout<<"blad\n";
          do_move(low,true,false);
          low_=low;
          nextMove();
        } else {
          low++;
          nextMove();
        }
      }
      low = low_;
    } else {
      while (bottom>=0) {
        if(visit[code(legal_moves2.mv[bottom])]){
          if(code(legal_moves2.mv[bottom])>CODES)cout<<"blad\n";
          do_move(bottom,false,true);
        } else {
          bottom--;
        }
      }
    }
  }


  

  int inline code_old(Move m){return (m.pos<<2)|m.dir;}
  int inline code(Move m) { 
    int c = code_old(m);
    return c;
    for (int i = 0; i < LINE; i++) {
      Position p = m.pos + dir[m.dir] * i;
      if (!has_dot[p]) {
        c = c*5 + i;
        break;
      } 
    }
    return c;
    int u = 3;
    for (int i = 0; i < LINE; i++) {
      Position p = m.pos + dir[m.dir] * i;
      if (has_dot[p] && u <= 2) {
        u++;
        c = (c)*4 + dir_dot[p];
      }
    }
    return c;
    cout<<"b";
    return code_old(m);
  }
  void init(int ile) {
    if(!PREV) { 
      low = 0;
      while(score<ile && low < legalMoves()){
        if(is_valid_move(low) &&  records[code(legal_moves.mv[low])]){
          do_move(low,false,false);
        }else {
            low++;
        }
      }
    }else{
      while(score<ile && bottom>=0){
        if(is_valid_move(bottom) &&  records[code(legal_moves2.mv[bottom])]){
          do_move(bottom,false,true);
        }else {
            bottom--;
        }
      }
    }
  }
  string show_dirs(int d) {
    const std::string green("\033[1;32m");
    const std::string yellow("\033[1;33m");
    if(d > 4)return yellow + "x";
    if(d == 4)return green + "4";
    if(d == 0)return yellow + " ";
    return yellow + " "; //std::to_string(d);
  }
  
  string show_dot(char c) {
    const std::string green("\033[1;32m");
    const std::string yellow("\033[1;33m");
    if(c=='P') {
      return green + "\u25A0";
    } else if(c=='K') {
      return yellow + "\u25CF";
    } else 
      return " ";
  }

  void display2() { 
    memset(dis, ' ', sizeof(dis));
    int min_x = 40;
    int min_y = 40;
    int max_x = 0;
    int max_y = 0;
    FOR(i,ARRAY__SIZE) {
      if(has_dot[i]){
        int x = i % _SIZE;
        int y = i / _SIZE;
        if(x<min_x)min_x = x;
        if(y<min_y)min_y = y; 
        if(x>max_x)max_x = x;
        if(y>max_y)max_y = y;
        dis[x*2][y*2] = 'P';
        FOR(d,4){
          if(is_line[i][d]){
            if(d==0){
              dis[x*2+1][y*2]='K';
             // dis[x*3+2][y*3]='K';
            } else if(d==1){
              dis[x*2+1][y*2+1]='K';
              //dis[x*3+2][y*3+2]='K';
            } else if(d==2){
              dis[x*2][y*2+1]='K';
              //dis[x*3][y*3+2]='K';
            } else if(d==3){
              dis[x*2-1][y*2+1]='K';
              //dis[x*3-1][y*3+2]='K';
            }
          }
        }
      }
    }
    FORU(y,2*min_y-1,2*max_y+1){
      FORU(x,2*min_x-1,2*max_x+1){
        std::cout<<show_dot(dis[x][y]);
      }
      std::cout<<"\n";
    }
  }
  void display() {
    const std::string red("\033[1;31m");
    const std::string green("\033[1;32m");
    const std::string yellow("\033[1;33m");
    const std::string cyan("\033[1;36m");
    const std::string magenta("\033[1;35m");
    const std::string reset("\033[0m");

    int min_x = 40;
    int min_y = 40;
    int max_x = 0;
    int max_y = 0;
    FOR(i,ARRAY__SIZE) {
      if(has_dot[i]){
        int x = i % _SIZE;
        int y = i / _SIZE;
        if(x<min_x)min_x = x;
        if(y<min_y)min_y = y; 
        if(x>max_x)max_x = x;
        if(y>max_y)max_y = y; 
      }
    }
    FORU(y,min_y-1,max_y+1){
      FORU(x,min_x-1,max_x+1){
      
        int p = y*_SIZE+x;
        if(has_dot[y*_SIZE+x]){
          cout << magenta<<" \u25A0"<<cyan<< show_dirs(dots_count[p][0]);
        } else {
          cout << magenta<<"  "<<cyan<<show_dirs(dots_count[p][0]);
        }
      }
      cout<<"\n";
      FORU(x,min_x-1,max_x+1){
        int p = y*_SIZE+x;
        cout<<show_dirs(dots_count[p][3])<<show_dirs(dots_count[p][2])<<show_dirs(dots_count[p][1]);
      }
      cout<<"\n";
    }

    cout << reset<<"\n";

  }
};

  int _score;
  int _level;
  int _length;
  int _moves[200];

  int symetria(int code) {
    int dir = code%4;
    code-=dir;code/=4;
    int y = code%40;
    code -= y; code/=40;
    int x = code;
    y = y+ 2*(19-y)+1;
    if(dir == 0) {
      if(y<=15){
        y+=4;
      }else{
        y-=4;
      }
      dir = 0;
    }

    else if(dir == 1) {
      dir = 3;
    }

    else if(dir == 2) {
      dir = 2;
    }

    else if(dir == 3) {
      dir = 1;
    }
    return (x*40+y)*4+dir;
  }

  int obrot(int code) {
    int dir = code%4;
    code-=dir;code/=4;
    int y = code%40;
    code -= y; code/=40;
    int x = code;

    //cout<<"x: "<<x<<" y: "<<y<<" dir: "<<dir<<"\n";

    //normalizuj
    double xp = (double)x - 19.5;
    double yp = (double)y - 19.5;


    xp = (double)y - 19.5;
    yp = -((double)x - 19.5);

    // powrot
    x = xp + 19.5;
    y = yp + 19.5;

    if(dir == 0){
        dir = 2;
    } else if(dir == 2){
        y-=4;
      dir = 0;
    } else if(dir == 1){
      dir = 3;
    } else if(dir == 3){
      // if((y>19 && x>19) || (y<=19 && x<=19)) {
        y-=4;
        x-=4;
     //  }
      dir = 1;
    }
    //cout<<"x: "<<x<<" y: "<<y<<" dir: "<<dir<<"\n\n";
    return (x*40+y)*4+dir;
  }
  bool records2[CODES];
  void read(int ile2, bool czy_symetria = false, int ile_obrotow = 0, bool(&t)[CODES] = records2) {
    PREV = false;
    memset(records2, false, sizeof(records2));
    memset(records, false, sizeof(records));
    std::ostringstream os;
    os << 'R' << ile2;
    std::string str = os.str();
    std::fstream myfile2("records/"+str+".txt", std::ios_base::in);
    myfile2 >> _score;
    myfile2 >> _level;
    myfile2 >> _length;
    
    for (int i = 0; i < ile2; i++) {
      myfile2 >> _moves[i];
      int c = _moves[i];
      if(czy_symetria)
        c = symetria(c);
      int h = ile_obrotow;
      while(h>0){
        c = obrot(c);
        h--;
      }
      records2[c]=true;
    }
    state ST;
        cout<<"ST.legalMoves(): "<<ST.legalMoves()<<"\n";
    ST.reset(0);
    ST.low = 0;
    cout<<"ST.legalMoves(): "<<ST.legalMoves()<<"\n";
    while(ST.low <  ST.legalMoves()) {
      cout<<ST.low<<" ";
      if(ST.is_valid_move(ST.low) && records2[ST.code_old(ST.legal_moves.mv[ST.low])]){
        records[ST.code(ST.legal_moves.mv[ST.low])] = true;
        ST.do_move(ST.low,false,false);
      } else {
        ST.low++;
      }
    }

    cout<<"ST.rec"<<ST.score<<"\n";
    PREV = true;
  }

  int CharDirToIntDir(char c)
  {
      switch (c) {
          case '-':
              return 0;
          case '\\':
              return 1;
          case '|':
              return 2;
          case '/':
              return 3;
          default:
              return -1;
      };
  }

  void read_policy() {
    std::fstream myfile2("policy/p140.txt", std::ios_base::in);
    for (int i = 0; i < 6400; i++) {
      myfile2>>policy[i];
    }
  }


  void read_pantasol(){
  
    int ile2 = 82;
    std::ostringstream os;
    os << 'M' << ile2;
    std::string str = os.str();
    std::fstream myfile2("records/"+str+".txt", std::ios_base::in);

    std::string wsp;
    char _dir;
    int pt;
    cout<<ile2<<"\n";
    for (int i = 0; i < ile2; i++) {
      myfile2>>wsp;
      myfile2>>_dir;
      myfile2>>pt;
      std::string s =  wsp.substr(1,2); 
      int y = std::stoi(s) - 10;
      s = wsp.substr(4,2); 
      int x = std::stoi(s) - 10;
      int dir = CharDirToIntDir(_dir);

      if( dir == 0 ) { // -
        y-= (2-pt);
      } else if (dir == 1) { 
        x += (pt-2);
        y -= (2-pt);
      } else if (dir == 2) { // |
        x += (pt-2);
      } else if (dir == 3) { // /
        x -= (pt+2);
        y += (pt+2);
      }
      int c = (x*40+y)*4+dir;
      cout<<c<<"\n";
      records[c]=true;
    }
  }

struct result {
  float time_spent;
  size_t memory_usage;
};
