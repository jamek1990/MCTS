#!/bin/sh
sudo apt update
sudo apt upgrade -y
sudo apt install cmake ninja-build g++ clang tmux htop -y
