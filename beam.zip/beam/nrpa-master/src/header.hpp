#pragma once

#include <iostream>
#include <limits>
#include <memory>
#include <cstring>
#include <algorithm>
#include <numeric>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <cmath>
#include <cassert>
#include <chrono>
#include <iomanip>
#include <bitset>
#include <fstream>
#include <filesystem>
#include <atomic>
#include <condition_variable>
#include <mutex>
#include <ext/pb_ds/assoc_container.hpp>

using namespace std;


// Macros

#define FOR(i, n) for(int64_t i = 0; i < (int64_t)(n); ++i)
#define FORU(i, j, k) for(int64_t i = (j); i <= (int64_t)(k); ++i)
#define FORD(i, j, k) for(int64_t i = (j); i >= (int64_t)(k); --i)

#define UNROLL_FOR8(i) _Pragma("GCC unroll 8") FOR(i,8)
#define UNROLL_FORD8(i) _Pragma("GCC unroll 8") FORD(i,7,0)

#define ALWAYS_INLINE __attribute__((always_inline))
#define FORCE_INLINE ALWAYS_INLINE inline

#define STRINGIZE(x) STRINGIZE2(x)
#define STRINGIZE2(x) #x
#define runtime_assert(x) do { if(!(x)) { throw runtime_error(__FILE__ ":" STRINGIZE(__LINE__) " Assertion failed: " #x); } } while(0)
#define impossible() do { throw runtime_error(__FILE__ ":" STRINGIZE(__LINE__) " impossible"); } while(0)
#define all(x) begin(x), end(x)
#define mp make_pair
#define mt make_tuple
#define pb push_back
#define eb emplace_back

// Types

template <class T> using min_queue = priority_queue<T, vector<T>, greater<T>>;
template <class T> using max_queue = priority_queue<T>;


struct uint64_hash {
  static inline uint64_t rotr(uint64_t x, unsigned k) {
    return (x >> k) | (x << (8U * sizeof(uint64_t) - k));
  }

  static inline uint64_t hash_int(uint64_t x) noexcept {
    auto h1 = x * (uint64_t)(0xA24BAED4963EE407);
    auto h2 = rotr(x, 32U) * (uint64_t)(0x9FB21C651E98DF25);
    auto h = rotr(h1 + h2, 32U);
    return h;
  }

  size_t operator()(uint64_t x) const {
    static const uint64_t FIXED_RANDOM = std::chrono::steady_clock::now().time_since_epoch().count();
    return hash_int(x + FIXED_RANDOM);
  }
};

template <typename K, typename V, typename Hash = uint64_hash>
using hash_map = __gnu_pbds::gp_hash_table<K, V, Hash>;
template <typename K, typename Hash = uint64_hash>
using hash_set = hash_map<K, __gnu_pbds::null_type, Hash>;



// Printing

template<class T>
void print_collection(ostream& out, T const& x);

template<class A>
ostream& operator<<(ostream& out, vector<A> const& x) { print_collection(out, x); return out; }
template<class A, int N>
ostream& operator<<(ostream& out, array<A, N> const& x) { print_collection(out, x); return out; }
template<class A>
ostream& operator<<(ostream& out, deque<A> const& x) { print_collection(out, x); return out; }
template<class A>
ostream& operator<<(ostream& out, multiset<A> const& x) { print_collection(out, x); return out; }
template<class A, class B>
ostream& operator<<(ostream& out, multimap<A, B> const& x) { print_collection(out, x); return out; }
template<class A>
ostream& operator<<(ostream& out, set<A> const& x) { print_collection(out, x); return out; }
template<class A, class B>
ostream& operator<<(ostream& out, map<A, B> const& x) { print_collection(out, x); return out; }

template<class T, size_t... I>
void print_tuple(ostream& out, T const& a, index_sequence<I...>);
template<class... A>
ostream& operator<<(ostream& out, tuple<A...> const& x) {
  print_tuple(out, x, index_sequence_for<A...>{});
  return out;
}

template<class T, size_t... I>
void print_tuple(ostream& out, T const& a, index_sequence<I...>){
  using swallow = int[];
  out << '(';
  (void)swallow{0, (void(out << (I == 0? "" : ", ") << get<I>(a)), 0)...};
  out << ')';
}

template<class T>
void print_collection(ostream& out, T const& x) {
  int f = 0;
  out << '[';
  for(auto const& i: x) {
    out << (f++ ? "," : "");
    out << i;
  }
  out << "]";
}

// Random

struct RNG {
  uint32_t x, y, z, w;

  RNG(uint64_t seed) {
    reset(seed);
  }

  RNG() {
    reset(time(0));
  }

  inline void reset(uint64_t seed) {

    struct splitmix64_state {
      uint64_t s;

      uint64_t splitmix64() {
        uint64_t result = (s += 0x9E3779B97f4A7C15);
        result = (result ^ (result >> 30)) * 0xBF58476D1CE4E5B9;
        result = (result ^ (result >> 27)) * 0x94D049BB133111EB;
        return result ^ (result >> 31);
      }
    };

    splitmix64_state s { seed };

    x = (uint32_t)s.splitmix64();
    y = (uint32_t)s.splitmix64();
    z = (uint32_t)s.splitmix64();
    w = (uint32_t)s.splitmix64();
  }

  inline uint32_t xorshift128() {
    uint32_t t = x;
    t ^= t << 11;
    t ^= t >> 8;
    x = y; y = z; z = w;
    w ^= w >> 19;
    w ^= t;
    return w;
  }

  // UniformRandomBitGenerator interface
  using result_type = uint32_t;
  constexpr uint32_t min(){ return numeric_limits<uint32_t>::min(); }
  constexpr uint32_t max(){ return numeric_limits<uint32_t>::max(); }
  uint32_t operator()() { return randomInt32(); }

  inline uint32_t randomInt32() {
    return xorshift128();
  }

  inline uint64_t randomInt64() {
    return (((uint64_t)randomInt32())<<32ll) | ((uint64_t)randomInt32());
  }

  inline uint32_t random32(uint32_t r) {
    return (((uint64_t)randomInt32())*r)>>32;
  }

  inline uint64_t random64(uint64_t r) {
    return randomInt64()%r;
  }

  inline uint32_t randomRange32(uint32_t l, uint32_t r) {
    return l + random32(r-l+1);
  }

  inline uint64_t randomRange64(uint64_t l, uint64_t r) {
    return l + random64(r-l+1);
  }

  inline double randomDouble() {
    return (double)randomInt32() / 4294967296.0;
  }

  inline float randomFloat() {
    return (float)randomInt32() / 4294967296.0;
  }

  template<class T>
  void shuffle(vector<T>& v) {
    int sz = v.size();
    for(int i = sz; i > 1; i--) {
      int p = random32(i);
      swap(v[i-1],v[p]);
    }
  }

  template<class T>
  inline int sample_index(vector<T> const& v) {
    return random32(v.size());
  }

  template<class T>
  inline T sample(vector<T> const& v) {
    return v[sample_index(v)];
  }
} rng;

// Letrec

template<class Fun>
class letrec_result {
  Fun fun_;
  public:
    template<class T>
    explicit letrec_result(T &&fun): fun_(forward<T>(fun)) {}

    template<class ...Args>
    decltype(auto) operator()(Args &&...args) {
      return fun_(ref(*this), forward<Args>(args)...);
    }
};

template<class Fun>
decltype(auto) letrec(Fun &&fun) {
  return letrec_result<decay_t<Fun>>(forward<Fun>(fun));
}

// Timer

struct timer {
  chrono::high_resolution_clock::time_point t_begin;

  timer() {
    t_begin = chrono::high_resolution_clock::now();
  }

  void reset() {
    t_begin = chrono::high_resolution_clock::now();
  }

  float elapsed() const {
    return chrono::duration<float>(chrono::high_resolution_clock::now() - t_begin).count();
  }
};

// Util

template<class T>
T& smin(T& x, T const& y) { x = min(x,y); return x; }

template <class T>
T& smax(T& x, T const& y) { x = max(x, y); return x; }

template <typename T> int sgn(T val) {
  if(val < 0) return -1;
  if(val > 0) return 1;
  return 0;
}

static inline
string int_to_string(int val, int digits = 0) {
  string s = to_string(val);
  reverse(all(s));
  while((int)s.size() < digits) s.pb('0');
  reverse(all(s));
  return s;
}


// Debug

static inline void debug_impl_seq() {
  cerr << "}";
}

template <class T, class... V>
void debug_impl_seq(T const& t, V const&... v) {
  cerr << t;
  if(sizeof...(v)) { cerr << ", "; }
  debug_impl_seq(v...);
}

#define AS_STRING_IMPL(x) #x
#define AS_STRING(x) AS_STRING_IMPL(x)
#define debug(x...) do {                                              \
    cerr << __FILE__ ":" AS_STRING(__LINE__) "  {" << #x << "} = {";  \
    debug_impl_seq(x);                                                \
    cerr << endl << flush;                                            \
  } while(0)
