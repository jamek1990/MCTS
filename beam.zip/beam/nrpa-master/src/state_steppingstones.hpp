#include <bits/stdc++.h>
#include <windows.h> // WinApi header
#include <cstdlib>
#include <iostream>
#include <ctime>
using namespace std;

const int dx[8] = {1, 1, 1, 0, -1, -1, -1, 0};
const int dy[8] = {-1, 0, 1, 1, 1, 0, -1, -1};

const int MAXN = 31;
const int SZ = 256;
const int SSZ = SZ * SZ;
const int MAX_GOAL = 350;
const int MAX_ATSUM = 64;

int HashArray[SSZ][MAX_GOAL];

void init_HashArray() {
  for (int i = 0; i < SSZ; i++) {
    for (int c = 0; c < MAX_GOAL; c++) {
      HashArray[i][c] = (rand()%100000000)*(rand()%100000000)*(rand()%100000000)*(rand()%100000000);
     // std::cout<<"h: "<<HashArray[i][c]<<"\n";
    }
  }
}

// NOTE: no performance impact
struct MoserDeBruijn_t {
  constexpr MoserDeBruijn_t() : X() {
    X[0] = 0;
    FOR(i, SZ - 1) X[i + 1] = (X[i] + 0xaaaaaaab) & 0x55555555;
  }
  int X[SZ];
} MoserDeBruijn;

const int GD[8] = {-SZ - 1, -SZ, -SZ + 1, 1, SZ + 1, SZ, SZ - 1, -1};
FORCE_INLINE
int point_at(int x, int y) {
  return MoserDeBruijn.X[x] + 2 * MoserDeBruijn.X[y];
};
FORCE_INLINE
int neigh(int z, int d) {
  if (d == 0)
    return (((z & 0xaaaaaaaa) - 1) & 0xaaaaaaaa) |
           (((z & 0x55555555) - 1) & 0x55555555);
  else if (d == 1)
    return (((z & 0xaaaaaaaa) - 1) & 0xaaaaaaaa) | (z & 0x55555555);
  else if (d == 2)
    return (((z & 0xaaaaaaaa) - 1) & 0xaaaaaaaa) |
           (((z | 0xaaaaaaaa) + 1) & 0x55555555);
  else if (d == 3)
    return (z & 0xaaaaaaaa) | (((z | 0xaaaaaaaa) + 1) & 0x55555555);
  else if (d == 4)
    return (((z | 0x55555555) + 1) & 0xaaaaaaaa) |
           (((z | 0xaaaaaaaa) + 1) & 0x55555555);
  else if (d == 5)
    return (((z | 0x55555555) + 1) & 0xaaaaaaaa) | (z & 0x55555555);
  else if (d == 6)
    return (((z | 0x55555555) + 1) & 0xaaaaaaaa) |
           (((z & 0x55555555) - 1) & 0x55555555);
  else if (d == 7)
    return (z & 0xaaaaaaaa) | (((z & 0x55555555) - 1) & 0x55555555);
  else
    impossible();
}

static inline vector<vector<int>> initial_states() {
  auto at = [&](int x, int y) { return point_at(SZ / 2 + x, SZ / 2 + y); };
  return {// 1
          // 32
          //   1
          {at(-1, -1), at(1, 1), at(0, 0), at(-1, 0)},
          // 1
          // 321
          {at(0, 1), at(-1, -1), at(0, 0), at(0, -1)},
          // 1
          //  21
          //  3
          {at(-1, -1), at(0, 1), at(0, 0), at(1, 0)},
          // 1
          //  21
          //   3
          {at(-1, -1), at(0, 1), at(0, 0), at(1, 1)},
          // 1 3
          //  21
          {at(-1, -1), at(0, 1), at(0, 0), at(-1, 1)},
          // 121
          // 3
          {at(-1, -1), at(-1, 1), at(-1, 0), at(0, -1)},
          // 1 1
          // 32
          {at(-1, -1), at(-1, 1), at(0, 0), at(0, -1)}};
}

const int MaxMoveNumber = 128;
const int MaxPlayoutLength = 101;

class Move {
public:
  int first;
  int second;
  int c;
  int hash = 0;
  Move() { hash = 0; }
  

  void add(int s) {
    hash = HashArray[first][s];
  }
};

int board2[SSZ];
int sum[SSZ];

// index of element in atsum
int atsum_index[SSZ][8];  // max degree = 8
int atsum_parent[SSZ][8]; // max degree = 8
int natsum_index[SSZ];

int ones[MAXN + 1];
int history[MAX_GOAL + MAXN];
int atsum[MAX_GOAL][MAX_ATSUM];
int natsum[MAX_GOAL];

class Board {
public:
  int nbMoves = 0;
  int maxn;
  int goal;
  Move moves[MaxMoveNumber];
  // all cells with given sum

  int nhistory;

  int n;
  int max_cell;
  Move rollout[MaxPlayoutLength];
  int length;
  int nbMovesLeft;
  int maxi;
  int hash;

  Board() { reset(8, 80); }
  int code(Move m) { return m.hash; }
  /*int legalMoves(Move moves[MaxLegalMoves]) {
    moves[0] = 0;
    moves[1] = 1;
    return 2;
  }*/

  int legalMoves() {
    int isz0 = natsum[max_cell + 1];
    int isz1 = natsum[max_cell];

    nbMoves = 0;

    FOR(i, isz0) {
      moves[nbMoves].second = -1;
      moves[nbMoves].first = atsum[max_cell + 1][i];
      moves[nbMoves].hash = 0;
      moves[nbMoves].add(max_cell+1);
      moves[nbMoves].c = hash^code(moves[nbMoves]);
      nbMoves++;
    }

    // chyba ze dodajemy 1
    if (n < maxn && max_cell > ones[n - 1] + 3) {
      FOR(i, isz1) {
        int x = atsum[max_cell][i];
        UNROLL_FORD8(d)
        if (board2[neigh(x, d)] == 0 && sum[neigh(x, d)] == 0) {
          moves[nbMoves].first = x;
          moves[nbMoves].second = neigh(x, d);
          moves[nbMoves].hash = 0;
          moves[nbMoves].add(max_cell+1);
          moves[nbMoves].c = hash^code(moves[nbMoves]);
          nbMoves++;
        }
      }
    }

    return nbMoves;
  }

  void play(const Move m) {
    if (m.second != -1) {
      set(m.second);
    }
    set(m.first);
    hash ^= m.hash;
  //  std::cout<<hash<<"\n";
    //  legalMoves();
    rollout[length] = m;
    length++;
  }

  FORCE_INLINE
  int score() { return max_cell; }

  void set(int x) {
    history[nhistory++] = x;
    int val = sum[x] == 0 ? 1 : sum[x];
    board2[x] = val;
    if (val == 1) {
      ones[n] = max_cell;
      n += 1;
    } else {
      if (max_cell != val - 1) {
        //  display();
        cout << "blad";
        impossible();
      }
      max_cell = val;
    }
    UNROLL_FOR8(d) {
      int y = neigh(x, d);
      if (board2[y] == 0) {
        int &sy = sum[y];
        if (2 <= sy && sy <= goal) {
          int ix = atsum_index[y][natsum_index[y] - 1];
          if (ix != natsum[sy] - 1) {
            atsum_index[atsum[sy][natsum[sy] - 1]]
                       [natsum_index[atsum[sy][natsum[sy] - 1]] - 1] = ix;
            swap(atsum[sy][ix], atsum[sy][natsum[sy] - 1]);
          }
          natsum[sy] -= 1;
        }
        sy += val;
        if (2 <= sy && sy <= goal) {
          atsum_parent[y][natsum_index[y]] = val;
          atsum_index[y][natsum_index[y]++] = natsum[sy];
          atsum[sy][natsum[sy]++] = y;
        }
      }
    }
  }

  void unset() {
    int x = history[--nhistory];
    int val = board2[x];
    UNROLL_FORD8(d) {
      int y = neigh(x, d);
      if (board2[y] == 0) {
        int &sy = sum[y];
        if (2 <= sy && sy <= goal) {
          natsum[sy] -= 1;
          natsum_index[y] -= 1;
        }
        sy -= val;
        if (2 <= sy && sy <= goal) {
          natsum[sy] += 1;
          int ix = atsum_index[y][natsum_index[y] - 1];
          if (ix != natsum[sy] - 1) {
            swap(atsum[sy][ix], atsum[sy][natsum[sy] - 1]);
            atsum_index[atsum[sy][natsum[sy] - 1]]
                       [natsum_index[atsum[sy][natsum[sy] - 1]] - 1] =
                           natsum[sy] - 1;
          }
          atsum[sy][ix] = y;
        }
      }
    }
    if (val == 1) {
      n -= 1;
    } else {
      max_cell = val - 1;
    }
    board2[x] = 0;
  }

  void reset(int maxn_, int goal_) {
    maxn = maxn_;
    goal = goal_;
    runtime_assert(2 <= maxn && maxn <= MAXN);
    runtime_assert(2 <= goal && goal < MAX_GOAL);

    FOR(i, SSZ) board2[i] = 0;
    FOR(i, SZ) board2[point_at(i, 0)] = -1;
    FOR(i, SZ) board2[point_at(i, SZ - 1)] = -1;
    FOR(i, SZ) board2[point_at(0, i)] = -1;
    FOR(i, SZ) board2[point_at(SZ - 1, i)] = -1;

    FOR(i, SSZ) sum[i] = 0;
    FOR(i, MAX_GOAL) natsum[i] = 0;
    FOR(i, SSZ) natsum_index[i] = 0;

    nhistory = 0;
    n = 0;
    max_cell = 1;
    nbMoves = 0;
    hash = 0;
    length = 0;
    auto IS = initial_states();
    for (auto i : IS[0]) {
      set(i);
    }
    legalMoves();
  }

  map<int, map<int, int>> normalize() const {
    int64_t minx = SZ, miny = SZ;
    FOR(i, SZ) FOR(j, SZ) if (board2[point_at(i, j)] > 0) {
      smin(minx, i);
      smin(miny, j);
    }
    map<int, map<int, int>> M;
    FORU(i, minx, SZ - 1)
    FORU(j, miny, SZ - 1)
    if (board2[point_at(i, j)] > 0)
      M[i - minx][j - miny] = board2[point_at(i, j)];
    return M;
  }

  void display(bool color = true) const {
    const std::string red("\033[1;31m");
    const std::string green("\033[1;32m");
    const std::string yellow("\033[1;33m");
    const std::string cyan("\033[1;36m");
    const std::string magenta("\033[1;35m");
    const std::string reset("\033[0m");

    auto M = normalize();
    for (auto const &[x, Mx] : M) {
      int last = 0;
      for (auto const &[y, v] : Mx) {
        while (last < y) {
          cout << "  . ";
          last += 1;
        }

        int nlower = 0;
        UNROLL_FOR8(d)
        if (M.count(x + dx[d]) && M[x + dx[d]].count(y + dy[d]) &&
            M[x + dx[d]][y + dy[d]] < v && M[x + dx[d]][y + dy[d]] != 1) {
          nlower++;
        }

        if (color) {
          if (nlower == 0)
            cout << magenta;
          else if (nlower <= 1)
            cout << yellow;
          else
            cout << cyan;
        }
        cout << setw(3) << v << " ";
        if (color) {
          cout << reset;
        }

        last += 1;
      }
      cout << endl;
    }
    cout << endl;
  }
};
