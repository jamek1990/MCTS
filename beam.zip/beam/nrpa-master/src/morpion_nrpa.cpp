#include <bits/stdc++.h>
#include <windows.h> // WinApi header
#include "fastexp.h"
using namespace std;

enum Variant { T5 = 0,
               D5 = 1 };
int variant = T5;
const int _SIZE = 40;
typedef int Direction;
typedef int Position;
static const int DIRS = 4;
static const int ARRAY__SIZE = _SIZE * _SIZE;
static const int LINE = 5;
const int dir[DIRS] = {1, _SIZE + 1, _SIZE, _SIZE - 1};
const int MaxLegalMoves = 40;


class Move {
 public:
  Position pos;
  Direction dir;
  Move() {}
  Move(Position pos, Direction dir) : pos(pos), dir(dir) {}
  int layer;
  int inline code(){return (pos<<2)|dir;}

};


class Board {
 protected:
  enum { RIGHT = 0,
         DOWN = 2,
         LEFT = 4,
         UP = 6 };

  bool has_dot[ARRAY__SIZE];
  int dots_count[ARRAY__SIZE][DIRS];
  int move_index[ARRAY__SIZE][DIRS];

 public:
 long long hash = 0;
  Move legal_moves[100];
  int legal_moves_size = 0;
  int length;
  inline Position PositionOfCoords(int x, int y) const {
    return x + y * _SIZE;
  }

  int ShiftFromDir(int d) { return d < DIRS ? dir[d] : -dir[d - DIRS]; }

  Board() {
    memset(has_dot, 0, sizeof(has_dot));
    memset(dots_count, 0, sizeof(dots_count));
    memset(move_index, 0, sizeof(move_index));
    length = 0;
    hash =0;
    legal_moves_size = 0;
    static const int cross[] = {
        RIGHT, UP, RIGHT, DOWN, RIGHT, DOWN, LEFT, DOWN, LEFT, UP, LEFT, UP};
    static const int ARMLEN = LINE - 2;
    Position p =
        PositionOfCoords((_SIZE - 3 * ARMLEN) / 2,
                         (_SIZE - ARMLEN) / 2);
    for (int i = 0; i < 12; i++) {
      int d = ShiftFromDir(cross[i]);
      for (int j = 0; j < ARMLEN; j++) {
        p += d;
        PutDot(p, 1);
      }
    }
    for(int i = 0; i < legal_moves_size; i++) {
      legal_moves[i].layer = 1;
    }
  };

  Board(const Board& g) {
    memcpy(has_dot, g.has_dot, sizeof(has_dot));
    memcpy(dots_count, g.dots_count, sizeof(dots_count));
    memcpy(move_index, g.move_index, sizeof(move_index));
    for(int i = 0; i <g.legal_moves_size;i++)
      legal_moves[i] = g.legal_moves[i];
    legal_moves_size =  g.legal_moves_size;
    length = g.length;
    hash = g.hash;
  };

  int legalMoves() {
    return legal_moves_size;
  };

  int score() {
    return length;
  };

  int play(Move move) {
    int layer = move.layer; 
    length++;
    for (int i = -(LINE - 2 + variant); i <= LINE - 2 + variant; i++)
      IncDotCount(move.pos + dir[move.dir] * i, move.dir, LINE);
    for (int i = 0; i < LINE; i++) {
      Position p = move.pos + dir[move.dir] * i;
      if (!has_dot[p]) {
        PutDot(p, 1);
        return p;
      }
    }
    for(int i = 0; i < legal_moves_size; i++) {
      if(legal_moves[i].layer==0){
        legal_moves[i].layer = layer + 1;
      }
    }
    
  };

 private:
  bool CanMove(Position pos, Direction d) const {
    return dots_count[pos][d] == LINE - 1;
  }

  void IncDotCount(Position pos, Direction d, int count) {
    if (CanMove(pos, d)) {
      int idx = move_index[pos][d];
      Move& back = legal_moves[legal_moves_size - 1];
      move_index[back.pos][back.dir] = idx;
      legal_moves[idx] = back;
      legal_moves_size--;
    }
    dots_count[pos][d] += count;
    if (CanMove(pos, d)) {
      move_index[pos][d] = legal_moves_size;
      legal_moves[legal_moves_size].dir = d;
      legal_moves[legal_moves_size++].pos = pos;
    }
  }
  void PutDot(Position pos, int count) {
    has_dot[pos] = count > 0;
    for (Direction d = 0; d < DIRS; d++) {
      Position p = pos;
      for (int i = 0; i < LINE; i++) {
        IncDotCount(p, d, count);
        p -= dir[d];
      }
    }
  }

  public: bool is_connected(const Move & move){
    int a = -(LINE - 2 + variant)-1;
    int b = LINE - 1;
    if( has_dot[move.pos + dir[move.dir] * a] || has_dot[move.pos + dir[move.dir] * b])return true;
   // if(dots_count[move.pos + dir[move.dir] * a][move.dir] != LINE-1 || dots_count[move.pos + dir[move.dir] * b][move.dir] != LINE-1)
    //return false;
    return false;
  }
};

bool code[1000000];
Move rollout_best[MaxLegalMoves];
int rollout_best_length;
Move rollout[MaxLegalMoves];
int rollout_length;

class ProbabilityCode {
 public:
  int code;
  double proba;
};

const int SizeTablePolicy = 6400;//32767;

template <typename M, int PL>
class Sequence {
 public:
  unsigned int length;
  int score = 0;
  int visit = 0;
  M mv[PL];
  Sequence() {
    init();
  }
  void init() {
    length = 0;
    score = 0;
    visit = 0;
  }

  char name[35];
  std::string token;

  void save() {
    std::fstream myfile("rek2/best2.txt", std::ios_base::in);
    int ile2;
    myfile >> ile2;
    if (ile2 >= score) return;
    std::cout << "saveBest\n";
    std::ostringstream os;
    os << score;
    std::string str = os.str();
    str = "rek1/" + str + ".txt";
    for (unsigned int i = 0; i < str.size(); i++)
      name[i] = str[i];
    std::ofstream o(name);
    o << length << "\n";
   /* for (unsigned int i = 0; i < length; i++) {
      mv[i].sort();
      int x = 15;
      int y = 15;
      for (unsigned int j = 0; j < mv[i].nbLocations; j++) {
        if (x > mv[i].locations[j] % 15) {
          x = mv[i].locations[j] % 15;
          y = 14 - mv[i].locations[j] / 15;
        } else if (x == mv[i].locations[j] % 15 && y > 14 - mv[i].locations[j] / 15) {
          x = mv[i].locations[j] % 15;
          y = 14 - mv[i].locations[j] / 15;
        }
      }

      o << y << " " << x << " c: " << mv[i].color + 1 << " p: " << mv[i].nbLocations << "\n";
    }*/

    //locations [0] % MaxSize, locations [0] / MaxSize)
    cout<<"\a";
    Beep(523,500);
    str = "rek2/best2.txt";
    char name2[30];
    strncpy(name2, str.c_str(), sizeof(name2));
    name2[sizeof(name2) - 1] = 0;
    std::ofstream o2(name2);
    o2 << score << "\n";
  }
  Sequence &operator=(const Sequence &s) {
    length = s.length;
    score = s.score;
    memcpy(mv, s.mv, length * sizeof(M));
    return *this;
  }
};


class Policy {
 public:
  std::vector<ProbabilityCode> table[SizeTablePolicy + 1];

  inline void setProb(int code, double proba) {
    int index = code & SizeTablePolicy;
    for (int i = 0; i < table[index].size(); i++) {
      if (table[index][i].code == code) {
        table[index][i].proba = proba;
        return;
      }
    }
    ProbabilityCode p;
    p.code = code;
    p.proba = proba;
    table[index].push_back(p);
  }

  inline void updateProb(int code, double delta) {
    int index = code & SizeTablePolicy;
    for (int i = 0; i < table[index].size(); i++) {
      if (table[index][i].code == code) {
        table[index][i].proba += delta;
        return;
      }
    }
    ProbabilityCode p;
    p.code = code;
    p.proba = delta;
    table[index].push_back(p);
  }

  inline double prob(int code) const {
    int index = code & SizeTablePolicy;
    for (int i = 0; i < table[index].size(); i++)
      if (table[index][i].code == code) {
        return table[index][i].proba;
      }
    return 0.0;
  }
  inline void reset() {
    for (int i = 0; i < SizeTablePolicy; i++) {
      table[i].clear();
    }
  }
};
class Policy2 {
  float w[6400];

 public:
  Policy2() {
    for (int i = 0; i < 6400; i++) {//70625
      w[i] = 1.0f;
    }
  }

  Policy2(const Policy2& _w) {
    memcpy(w, _w.w, sizeof(w));
  }

  Policy2& operator=(const Policy2& _w) {
    memcpy(w, _w.w, sizeof(w));
    return *this;
  }

  float& operator[](int i) {
    return w[i];
  }

  const float& operator[](int i) const {
    return w[i];
  }

  inline float prob(int code) const {
    return w[code];
  }

  inline void setProb(int code, float proba) {
    w[code] = proba;
  }

  inline void updateProb(int code, double delta) {
    w[code] *= delta;
  }
};

void set_best(int ile) {
    string str;
    str = "rek2/best2.txt";
    char name2[30];
    strncpy(name2, str.c_str(), sizeof(name2));
    name2[sizeof(name2) - 1] = 0;
    std::ofstream o2(name2);
    o2 << ile << "\n";
}
class Rollout {
 public:
  Rollout(){};

  Rollout(int level) : _level(level), _score(numeric_limits<int>::lowest()) {}
  Rollout(int *rolloutData, int length, int level, int score) : _length(length), _level(level), _score(score) {
    addAllMoves(rolloutData, length);
  }

  /* store rollout into filename */
  void store(const string &filename, const string &lockfile) const;

  /* load rollout from file*/
  void load(const string &filename, const string &lockfile);

  void compareAndSwap(const string &filename, const string &lockfile);

  //  inline const int *data() const { return &front(); }
  inline int length() const { return _length; }
  inline int score() const { return _score; }
  inline int level() const { return _level; }
  inline int move(int step) const {
    assert(step < length());
    return _moves[step];
  }

  inline void setScore(int score) { _score = score; }

  inline void addMove(int code) { _moves[_length++] = code; }

  inline std::vector<int> *moves() {
    assert(false);
    return 0;
  }

  inline void addAllMoves(int *moves, int length) {
    std::copy(moves, moves + length, _moves);
    _length = length;
  }

  inline void reset() {
    _score = std::numeric_limits<int>::lowest();
    _length = 0;
  }

  char name[35];
  std::string token;
  void save(int score) {
    std::fstream myfile("rek2/best2.txt", std::ios_base::in);
    int ile2;
    myfile >> ile2;
    if (ile2 >= score) return;
    std::ostringstream os;
    os << 'R' << score;
    std::string str = os.str();
    str = "rek2/" + str + ".txt";
    for (unsigned int i = 0; i < str.size(); i++)
      name[i] = str[i];
    std::ofstream o(name);
    o <<_score<< "\n";
    o <<_level<< "\n";
    o <<_length<< "\n";
    for (int i = 0; i < _length; i++) {
      o << _moves[i] << "\n";
    }
    set_best(score);
  }

  void read(int score) {
    std::fstream myfile("rek2/best2.txt", std::ios_base::in);
    int ile2;
    myfile >> ile2;
    if (ile2 <= score) return;
    std::ostringstream os;
    os << 'R' << ile2;
    std::string str = os.str();
    std::fstream myfile2("rek2/"+str+".txt", std::ios_base::in);
    myfile2 >> _score;
    myfile2 >> _level;
    myfile2 >> _length;
    for (int i = 0; i < _length; i++) {
      myfile2 >> _moves[i];
    }
  }
  

 private:
  int _moves[200];
  int _length;
  int _level;
  int _score;
};

class LegalMoves {
 public:
  inline void setNbSteps(int step) {
    _nbSteps = step;
  }

  inline void addStep() {
    _nbSteps++;
  }

  inline void setNbMoves(int step, int size) {
    assert(step < _nbSteps);
    _nbMoves[step] = size;
  }

  inline void addMove(int step, int move) {
    assert(step < _nbSteps);
    int idx = _nbMoves[step]++;
    _moves[step][idx] = move;
  }

  inline void setMove(int step, int idx, int move) {
    assert(step < _nbSteps);
    assert(idx < _nbMoves[step]);
    _moves[step][idx] = move;
  }

  inline int nbMoves(int step) const {
    //   assert(step < _nbSteps);
    return _nbMoves[step];
  }

  inline int move(int step, int idx) const {
    // assert(step < _nbSteps && idx < _nbMoves[step]);
    return _moves[step][idx];
  }

  inline void copy(const LegalMoves &lm) {
    _nbSteps = lm._nbSteps;
    std::copy(lm._nbMoves, lm._nbMoves + _nbSteps, _nbMoves);
    for (int i = 0; i < _nbSteps; i++)
      std::copy(lm._moves[i], lm._moves[i] + lm._nbMoves[i], _moves[i]);
  }

  inline void operator=(const LegalMoves &lm) {
    this->copy(lm);
  }

  inline void resetStep() {
    _nbSteps = 0;
  }

  char name[35];
  std::string token;
  void save(int score) {
    std::fstream myfile("rek2/best2.txt", std::ios_base::in);
    int ile2;
    myfile >> ile2;
    if (ile2 > score) return;
    std::ostringstream os;
    os << 'L' << score;
    std::string str = os.str();
    str = "rek2/" + str + ".txt";
    
    for (unsigned int i = 0; i < str.size(); i++)
      name[i] = str[i];
    std::ofstream o(name);
    o << _nbSteps << "\n";
    for (int i = 0; i < 200; i++) {
      o << _nbMoves[i] << "\n";
    }
    for (int i = 0; i < 200; i++) {
      for (int j = 0; j < 200; j++) {
        o << _moves[i][j] << "\n";
      }
    }
  }


  void read(int _score) {
    std::fstream myfile("rek2/best2.txt", std::ios_base::in);
    int ile2;
    myfile >> ile2;
    if (ile2 <= _score) return;
    std::ostringstream os;
    os << 'L' << ile2;
    std::string str = os.str();
    std::fstream myfile2("rek2/"+str+".txt", std::ios_base::in);
    myfile2 >> _nbSteps;
    for (int i = 0; i < 200; i++) {
      myfile2 >> _nbMoves[i];
    }
    for (int i = 0; i < 200; i++) {
      for (int j = 0; j < 200; j++) {
        myfile2 >> _moves[i][j];
      }
    }
  }
  inline void reset() {
    for (int i = 0; i < _nbSteps; i++)
      _nbMoves[i] = 0;
    _nbSteps = 0;
  }

 private:
  int _nbSteps;
  int _nbMoves[200];
  int _moves[200][200];
};

const int NRPA_N = 100;
Policy2 policy[7];
LegalMoves legalMoveCodes[7];
Rollout bestRollout[7];
Sequence<Move, 200> sequence[7];
bool _tabu[6400];
int S = 1;
double getBias(Move & move ,Board & board) {
  
 // if(_tabu[move.code()])return 0.90;
 // if(S%2)
  //return 1.0+(double)move.layer/200.0;
  //else
 // return 1.0-(double)move.layer/200.0;
  //if(board.is_connected(move))return 2.25;
  return 1.0;
}
void updatePolicy(int level) {
  int length = bestRollout[level].length();
  for (int step = 0; step < length; step++) {
    double z = 0.;
    for (int i = 0; i < legalMoveCodes[level].nbMoves(step); i++) {
      int move = legalMoveCodes[level].move(step, i);
      double bias = 0;//getBias(_tabu, _size, tab_col, move);
      z += fastexp(policy[level].prob(legalMoveCodes[level].move(step, i))+bias);
    }
    int code = bestRollout[level].move(step);
    for (int i = 0; i < legalMoveCodes[level].nbMoves(step); i++) {
      int move = legalMoveCodes[level].move(step, i);
      double bias = 0;//getBias(_tabu, _size, tab_col,move);
      policy[level].updateProb(move, -fastexp(policy[level].prob(move)+bias) / z);
    }
    policy[level].setProb(code, policy[level].prob(code) + 1.0);
  }
}
Board root;
long long int layer[640000];
Move mvs[100];
int mvs_length = 0;
int ln = 0;
void updatePolicy2(int level) {
  int length = bestRollout[level].length();
  Board board(root);

  Policy2 w2 = policy[level];
  
  ln += 2;
  for (size_t i = 0; i < length; i++) 
    layer[bestRollout[level].move(i)] = ln;
  
  for (size_t i = 0; i < length; i++) {
    if (layer[bestRollout[level].move(i)] < ln) continue;
    mvs_length = 0;
    float ww = 0.0f;
    for (unsigned int j = 0; j < board.legal_moves_size; j++) {
      if (layer[board.legal_moves[j].code()] == ln) {
        mvs[mvs_length++] = board.legal_moves[j];
        layer[board.legal_moves[j].code()]--;
      }
      //ww += fastexp(w2.prob(board.legal_moves[j].code()));
      double bias =  getBias(board.legal_moves[j], board);
      ww += w2.prob(board.legal_moves[j].code())*bias;
    }
    float invW = 1.0f / ww;
    float rrr = 1.0;
    for (unsigned int j = 0; j < board.legal_moves_size; j++) {
      int move = board.legal_moves[j].code();
     // policy[level].updateProb(move, -fastexp(mvs_length * w2.prob(move)) * invW);
     // policy[level].updateProb(move, -fastexp( mvs_length * w2.prob(move) * invW ) +
                                                 //   (layer[move] == ln - 1 ? 1.0*rrr : 0));

       double bias =  getBias(board.legal_moves[j], board);
       policy[level].updateProb(move, fastexp(-( mvs_length * w2.prob(move)* bias * invW -(layer[move] == ln - 1 ? 1.0*rrr : 0))));

    }
    
    for (unsigned int j = 0; j < mvs_length; j++) {
      board.play(mvs[j]);
    }
  }
};

void get_hash(Rollout & l) {
  Board board(root);
  string hash = "";
  while (board.legal_moves_size> 0) {
    int choose = -1;
    for(int i = 0; i < board.legal_moves_size; i++) {
      for(int j = 0; j< l.length(); j++) {
        if(board.legal_moves[i].code() == l.move(j)) {
          choose = i;break;
        }
      }
      if(choose>=0)break;
    }
    hash += (char) (choose + 65);
    board.play(board.legal_moves[choose]);
  }
  cout<<l.score()<<"\t"<<hash<<"\n";
}


int ile = 0;
int playout() {
  ile++;
  Board board(root);
  bestRollout[0].reset();
  legalMoveCodes[0].setNbSteps(0);
  sequence[0].init();int nr = 0;


  int tab_col = 0;
  while (board.legal_moves_size> 0) {
    int step = bestRollout[0].length();
    double moveProbs[MaxLegalMoves];
    legalMoveCodes[0].setNbSteps(step + 1);
    legalMoveCodes[0].setNbMoves(step, board.legal_moves_size);

    for (int i = 0; i < board.legal_moves_size; i++) {
      int c = board.legal_moves[i].code();
      double bias =  getBias(board.legal_moves[i], board);
      moveProbs[i] = policy[1].prob(c)*bias;
      legalMoveCodes[0].setMove(step, i, c);
    }
    double sum = moveProbs[0];
    for (int i = 1; i < board.legal_moves_size; i++) {
      sum += moveProbs[i];
    }

    double r = (rand() / (RAND_MAX + 1.0)) * sum;
    double s = 0.0f;
    int j = board.legal_moves_size - 1;
    for (int i = 0; i < board.legal_moves_size; i++) {
      s += moveProbs[i];
      if (s >= r) {
        j = i;
        break;
      }
    }

    bestRollout[0].addMove(legalMoveCodes[0].move(step, j));
    sequence[0].mv[sequence[0].length++]=board.legal_moves[j];
    board.play(board.legal_moves[j]);
  }
  int score = board.score();
  sequence[0].score = score;
  bestRollout[0].setScore(score);
  return score;
}

int rem[6400];
int rem_d[6400];
int rem_d_size = 0;
int rem_score[6400];
int rem_ile[6400];
Rollout dnal[10];
float dna[6400];
Rollout record;
bool record_dna[6400];
void read_record() {
  set_best(172);
  record.read(171);
  cout<<"RECORD: "<<record.length()<<"\n";
  for (int i = 0; i <record.length(); i++)
      record_dna[record.move(i)]=true;
  set_best(0);
}
void dna_minus() {
    for (int i = 0; i <dnal[0].length(); i++)
      rem_score[dnal[0].move(i)]--;
}

void dna_plus() {
    for (int i = 0; i <dnal[0].length(); i++)
      rem_score[dnal[0].move(i)]+=10000;
}

void dna_update() {
    int score = dnal[0].score();
    for(int i = 0; i <dnal[0].length(); i++) {
      if(rem_score[dnal[0].move(i)] < score)
        rem_score[dnal[0].move(i)] = score;
      rem_ile[dnal[0].move(i)]++; 
    }
}

void redukuj(int max_score) {
  int maks = 10000000;
  int maks_ile = 0;
  int choose = -1;
  for(int i = 0; i < 6400; i++) {
    if(!rem[i]) {
      if(rem_score[i] < max_score-25  && maks_ile < rem_ile[i] ) {
        maks_ile = rem_ile[i];
        choose = i;
      }
    }
  }
  if(maks_ile > 2000) {
    if(record_dna[choose])cout<<" R ";
    rem_d[rem_d_size++]=choose;
    cout<<"*";
    rem[choose] = true;
    rem_ile[choose] = 0; 
  }
  //for(int i = 0; i < 6400; i++) {rem_score[i]=10;}
}
void eval_dna( Rollout & l) {
  l.reset();
  sequence[0].init();
  Board board(root);
  int chosen;
  legalMoveCodes[0].setNbSteps(0);
  while (board.legal_moves_size > 0) {
    int step = board.length;
    chosen = rand() % board.legal_moves_size;
    float mv = 0;
    int j = board.legal_moves_size;
    int g = board.legal_moves_size;
    int start = rand() % g;
    legalMoveCodes[0].setNbSteps(step + 1);
  legalMoveCodes[0].setNbMoves(step, board.legal_moves_size);
    for (unsigned int i = 0; i < board.legal_moves_size; i++){
      int c = board.legal_moves[i].code();
      legalMoveCodes[0].setMove(step, i, c);
    }
    while (j--) {
      int i = (start + j) % g;
      float v = dna[board.legal_moves[i].code()];
      if (v >= mv) {
        mv = v;
        chosen = i;
       // break;
      }
    }
   // if (mv == 0) chosen = rand() % board.legal_moves_size;
    if(step==0)chosen=1;
    l.addMove(board.legal_moves[chosen].code());
    sequence[0].mv[sequence[0].length++]=board.legal_moves[chosen];
    board.play(board.legal_moves[chosen]);
  }
  sequence[0].score = board.score();
  l.setScore(board.score());
};

int ss = 0;
void modification_x( Rollout & morpion, Rollout & l, int ile) {
 // for (int i = 0; i < morpion.length(); i++)
   // dna[morpion.move(i)] = morpion.length() + 1 - i;
  ss++;
   int H = 2048;
  if (rand() % 20 != 0)
    for (int i = 0; i < morpion.length(); i++)
      dna[morpion.move(i)] = 20+ i   + rand()%3;
  else
    for (int i = 0; i < morpion.length(); i++)
      dna[morpion.move(i)] = 20 + i;

  if(ile > 0) {
    int position = ss % morpion.length();
    dna[morpion.move(position)] = -1.0;

    ile--;
  }
  while (ile--) {
    int position = rand() % morpion.length();
    dna[morpion.move(position)] = 0.0;
  }
  for(int i = 0; i < rem_d_size;i++)
    dna[rem_d[i]] = -0.5;
  eval_dna( l);
  for (int i = 0; i < morpion.length(); i++)
    dna[morpion.move(i)] = 0;
}


void run_dna() {
  int sim = 0;
  Rollout l;
  l.reset();
  Board board(root);
  while (board.legal_moves_size > 0) {
    int chosen = rand() % board.legal_moves_size;
    l.addMove(board.legal_moves[chosen].code());
    board.play(board.legal_moves[chosen]);
  }

  Rollout nl;
  int max_wynik = 0;
  while(1){
    sim++;
    modification_x( l, nl, 1+rand()%5);
    if (nl.score() >= max_wynik){
      l = nl;
    }
    if (max_wynik < l.score()) {
      max_wynik = nl.score();
      std::cout << "\nBEST WYNIK " << max_wynik << " ( "<<sim<< " )\n";
    }
  }
}

int max_Score = 0;
int WWW = 100;
int r = 0;
void run_dna2() {
  int sim = 0;

  Board board(root);

  int step = 0;
  Rollout l;
   Rollout l2;
  l.reset();
  while (board.legal_moves_size > 0) {
    int chosen = rand() % board.legal_moves_size;
    l.addMove(board.legal_moves[chosen].code());
    board.play(board.legal_moves[chosen]);
  }
  l2 = l;
  Rollout nl;
  int max_wynik = 0;
  int H = 0;
  while (true) {

    if(H%25000 == 0) {
      cout<<"S";
      l = l2;
      while(true){ 
        sim++;
        modification_x(l2, nl, 1 + rand() %10);
        if (nl.score() >= max_wynik) {
          l = nl;
        }
        if( nl.score() + 50 > l2.score() ) {
          l = nl;
          cout<<"E";
          break;
        }
      }
    }
    sim++;
    modification_x(l, nl, rand() %10); 
    if(l.score() <= nl.score()) {
      l = nl;
    }
    
    if (max_Score < l.score()) {
      max_Score = l.score();
      std::cout << "\nBEST WYNIK " << max_Score << " ( " << sim << " )\n";
      l2 = l;
    }
    H++;
  }
}

int H1 = 500;
int H2 = 500;
int U = 1;

void ndna(int level) {
  int i = H1;
  if(level!=1)i = H2;
  while (i--) {
    if(level == 1) {
       modification_x(dnal[level], dnal[level-1], 1 +  rand() %5);
       dna_update();
       /*if(dnal[level-1].score() +100 < max_Score) {
         dna_minus();
       }
       if(dnal[level-1].score() +75  > max_Score) {
         dna_plus();
       }*/
       if(dnal[level-1].score() > max_Score){
        max_Score = dnal[level-1].score();
        dnal[level-1].save(max_Score);
        
        for(int i = 0; i < rem_d_size;i++) {
          dna[rem_d[i]] = 0;
          rem[rem_d[i]] = 0;
        //  rem_score[rem_d[i]]=50;
        }
        for(int i = 0; i < 6400; i++) {rem_ile[i]=0;}
        rem_d_size = 0;
        cout<<"max_Score: "<<max_Score<<"\n";
      }
       if( dnal[level-1].score() >  dnal[level].score() ) { i+=H1; i = max(i,H1);}
       if( dnal[level-1].score() >= dnal[level].score() ) {
        dnal[level] = dnal[level-1];
      }
    } else {
      if( dnal[level-1].score() >= dnal[level].score() ) {
        if( dnal[level-1].score() >  dnal[level].score() ) { i+=H2; i = max(i,H2);}
        dnal[level] = dnal[level-1];
      }
      modification_x(dnal[level], dnal[level-1], 1+ rand() %3);
      int u = U;
      while(u--) {
        modification_x(dnal[level], dnal[level-2], 1+ rand() % 3); 
        if(dnal[level-2].score() > dnal[level-1].score())dnal[level-1] = dnal[level-2];
      } 
      ndna(level - 1);
      
    } 
    if(level==2 && rand()%15==0) {
      cout<<"|";
      dnal[level].read(max_Score); 
    }
    if(level==2 && rand()%15==0) {
       cout<<"-";
      redukuj(max_Score);
      r++;
      if(r%25 ==0){
        cout<<"reset\n";
        for(int i = 0; i < rem_d_size;i++) {
          dna[rem_d[i]] = 0;
          rem[rem_d[i]] = 0;
        //  rem_score[rem_d[i]]=50;
        }
        for(int i = 0; i < 6400; i++) {rem_ile[i]=0;}
        rem_d_size = 0;
      }
    }
   

      
      
  }
}

void ndna_start() {
  Board board(root);
  dnal[2].reset();
  while (board.legal_moves_size > 0) {
    int chosen = rand() % board.legal_moves_size;
    dnal[2].addMove(board.legal_moves[chosen].code());
    board.play(board.legal_moves[chosen]);
  }
  for(int i = 7; i>=0;i--)dnal[i]=dnal[2];
  ndna(2);
}

bool code_level[10][6400];

int nrpa(int level) {
  bestRollout[level].reset();
  policy[level] = policy[level + 1];
  int NN = NRPA_N;
  //if(level>=3)NN = 30;
 // if(level==1)NN+=5;
  NN = WWW;
  for (int i = 0; i < NN; i++) {
    int adapt = 1;
    int score = 0;
    bool ok = false;
    if (level == 1) {
      
      
      if(i>1 && rand()%20==0){
        i--;
        adapt = 0;
        //while(h--){
        modification_x( bestRollout[level], bestRollout[level - 1], 3);
        
      }else{
        playout();
      }
      if (bestRollout[level - 1].score()  >= bestRollout[level].score()) {
        if (bestRollout[level - 1].score()  > bestRollout[level].score()) ok = true;
        bestRollout[level] = bestRollout[level - 1];
        
       // legalMoveCodes[level] = legalMoveCodes[level - 1];
      }else{
        ok = true;
      }
      if (bestRollout[level].score() > max_Score) {
        max_Score = bestRollout[level].score();
        cout<<"\n";
        get_hash(bestRollout[level]);
        cout << max_Score << " ("<<ile<<")\n";
     ///   sequence[0].save();
      //  bestRollout[level].save(max_Score);
      //  legalMoveCodes[level].save(max_Score);
      } 

      
    } else {
    //  for(int ii = 0; ii < 6400; ii++)

      nrpa(level - 1);
    }
    if (bestRollout[level].score() >= bestRollout[level + 1].score()) {
      bestRollout[level + 1] = bestRollout[level];
     // legalMoveCodes[level + 1] = legalMoveCodes[level];
    }else{

    }
    if(level==3 && rand()%30==0) {//
      cout<<"|";
    //  bestRollout[level].read(max_Score);
    //  S++;
      
   //   legalMoveCodes[level].read(max_Score);
    }
    if(level==4) {
      
      cout<<"T";
    /*  for(int ii =0;ii<6400;ii++)_tabu[ii]=false;
      int yy = bestRollout[level].length();
      if(yy>0){
        int u = 3;
        while(u--){
          _tabu[rand()%yy]=true;
        }
      }*/
    }
    if(adapt && level == 1)// && ok)
      updatePolicy2(level);
    if(adapt && level > 1)
      updatePolicy2(level);
  }
  return max_Score;
}


int main() {
  srand(time(NULL));
//  read_record();
  set_best(0);
while(1) {
  set_best(0);
  ndna_start();
  cout<<"###\n";
}
 // cin>>WWW;
//nrpa(5);
 // run_dna2();
  return 0;
}